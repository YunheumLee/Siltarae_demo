# Nano 33 BLE Rev2 Flex Air Mouse

Arduino Nano 33 BLE Rev2, Flex sensor A0/A1, BLE HID Mouse를 사용하는 보조 입력 장치 예제입니다.

## 가장 쉬운 실행 방법

Windows에서 아래 파일을 더블클릭합니다.

```text
AirMouse_Setup_App.exe
```

Python이 설치된 개발 환경에서는 아래 배치 파일로도 실행할 수 있습니다.

```text
AirMouse_Setup_App.bat
```

그러면 통합 setup app이 열립니다.
앱 안에서 순서대로 버튼을 누르면 됩니다.

```text
1. Python 패키지 설치
2. Gyro_RawLogger.ino 열기
3. Gyro calibration GUI 실행
4. Test1_FlexSensor.ino 열기
5. Flex / Click / IMU calibration GUI 실행
6. 최종 Test1_FlexSensor.ino 열기
```

실제 Arduino 업로드는 Arduino IDE에서 사용자가 직접 눌러야 합니다.
Python GUI 실행과 calibration 결과 반영은 setup app에서 버튼으로 처리됩니다.

## exe 다시 만들기

소스 코드를 수정한 뒤 exe를 다시 만들고 싶으면 아래 파일을 실행합니다.

```text
build_windows_exe.bat
```

완료되면 같은 폴더에 아래 파일이 생깁니다.

```text
AirMouse_Setup_App.exe
```

단, `.exe`만 단독으로 옮기면 안 됩니다. `Gyro_Calibration`, `Test1_FlexSensor`, `Test1_FlexSensor_Calibration` 폴더와 같은 위치에 있어야 합니다.

## 폴더 구성

```text
Gyro_Calibration/
  자이로 raw data 수집, gyro bias/scale 계산, Test1_FlexSensor 자동 반영

Test1_FlexSensor_Calibration/
  A0/A1 클릭 threshold, 더블클릭 시간, 드래그 시간, IMU 감도 GUI calibration

Test1_FlexSensor/
  최종 BLE 마우스 Arduino runtime
```

## 준비물

- Arduino Nano 33 BLE Rev2
- Flex sensor 2개
  - A0: 좌클릭
  - A1: 우클릭
- Arduino IDE
- Python 3.10 이상 권장
- Arduino Library
  - `Arduino_BMI270_BMM150`
  - `HIDMouse`

Python 패키지 설치:

```powershell
cd "업로드폴더"
python -m pip install -r Gyro_Calibration/requirements.txt
```

## 전체 순서

### 1. 자이로 정밀 calibration

먼저 raw logger를 Arduino에 업로드합니다.

```text
Gyro_Calibration/Gyro_RawLogger/Gyro_RawLogger.ino
```

그 다음 GUI를 실행합니다.

```powershell
cd "업로드폴더"
python Gyro_Calibration/gyro_calibration_gui.py --port COM3
```

GUI 안내에 따라 진행합니다.

- 시작 전 정지 수집
- +X, -X, +Y, -Y, +Z, -Z 방향으로 각각 360도 회전
- 끝난 뒤 정지 수집

가능하면 손으로 눈대중 회전하지 말고, 모서리, 지그, 물리적 stop을 사용해 정확히 한 바퀴 회전하세요.

GUI 수집이 끝나면 자동으로 fit과 적용까지 실행됩니다.
즉 아래 파일들이 자동으로 생성/갱신됩니다.

- `gyro_fit_result.json` 생성
- `Test1_FlexSensor_Calibration/test1_flex_calibration.json` 갱신
- `Test1_FlexSensor/flex_config.h` 갱신

기존 session을 다시 적용하고 싶을 때만 아래 명령을 따로 실행하세요.

```powershell
python Gyro_Calibration/fit_and_apply_gyro_calibration.py
```

### 2. Test1_FlexSensor 임시 업로드

Flex calibration GUI는 Arduino runtime의 Serial stream을 사용합니다.
따라서 아래 스케치를 한 번 업로드합니다.

```text
Test1_FlexSensor/Test1_FlexSensor.ino
```

### 3. Flex sensor와 IMU 사용감 calibration

GUI를 실행합니다.

```powershell
python Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py --port COM3
```

GUI에서 Enter와 좌우 방향키를 사용합니다.

- A0 좌클릭 threshold
- A1 우클릭 threshold
- A0 길게: 더블클릭 시간
- A1 길게: 드래그 시작 시간
- A0+A1 길게: 마우스 X/Y 방향 부호 전환 시간
- IMU 수평 감도
- IMU 수직 감도
- 떨림 제거 deadzone

Flex GUI는 gyro bias/scale을 새로 덮어쓰지 않습니다. 정밀 자이로 값은 1단계 결과를 유지합니다.

### 4. 최종 업로드

Flex GUI에서 저장한 뒤, 최종적으로 다시 업로드합니다.

```text
Test1_FlexSensor/Test1_FlexSensor.ino
```

업로드 후 Windows Bluetooth에서 BLE 마우스를 연결합니다.

```text
Nano Flex Mouse T1
```

## 동작 요약

- A0 짧게 구부렸다 펴기: 좌클릭
- A1 짧게 구부렸다 펴기: 우클릭
- A0 오래 유지 후 펴기: 더블클릭
- A1 오래 유지: 드래그 시작
- 드래그 중 A1 펴기: 드롭
- A0 + A1 오래 유지: 손등/손바닥 방향 전환용 마우스 X/Y 부호 반전
- IMU 기울임/회전: BLE 마우스 커서 이동

## 자주 헷갈리는 점

`A0 + A1 hold`는 X축과 Y축을 서로 바꾸는 기능이 아닙니다.
X축은 X축으로, Y축은 Y축으로 유지하고, 두 축의 마우스 이동 방향 부호만 반대로 바꿉니다.

`Test1_FlexSensor` 안의 `BIAS` Serial 명령은 빠른 확인용입니다.
정밀 calibration을 사용하는 경우에는 `Gyro_Calibration/fit_and_apply_gyro_calibration.py`를 사용하세요.
