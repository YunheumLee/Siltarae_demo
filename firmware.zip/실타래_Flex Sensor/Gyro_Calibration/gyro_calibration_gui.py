#!/usr/bin/env python3
"""GUI collector for Nano 33 BLE Rev2 gyro calibration."""

from __future__ import annotations

import argparse
import csv
import json
import math
import queue
import threading
import time
import tkinter as tk
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from tkinter import messagebox

try:
    import serial
    from serial.tools import list_ports
except ImportError as exc:
    raise SystemExit("Install pyserial first: pip install pyserial") from exc

from fit_and_apply_gyro_calibration import apply_to_flex_config, fit_session


PORT = "AUTO"
BAUD = 115200
STATIC_SECONDS = 45.0
TARGET_ANGLE_DEG = 360.0
REPEATS = 3

SESSION_ROOT = Path(__file__).resolve().parent / "calibration_sessions"
PACKAGE_ROOT = Path(__file__).resolve().parent.parent

SAMPLE_COLUMNS = [
    "record_type",
    "t_us",
    "trial_id",
    "phase",
    "axis",
    "direction",
    "target_angle_deg",
    "gx_dps",
    "gy_dps",
    "gz_dps",
    "event",
]


@dataclass
class Step:
    trial_id: str
    phase: str
    axis: str
    direction: str
    target_angle: float
    title: str
    guide: str
    auto_seconds: float = 0.0


def choose_serial_port(requested: str) -> str:
    if requested and requested.upper() != "AUTO":
        return requested

    ports = list(list_ports.comports())
    keywords = ("ARDUINO", "NANO", "MBED", "USB SERIAL", "USB")
    for port in ports:
        text = " ".join([port.device or "", port.description or "", port.manufacturer or ""]).upper()
        if any(keyword in text for keyword in keywords):
            return port.device
    if ports:
        return ports[0].device
    return "COM3"


def build_steps(repeats: int, static_seconds: float, target_angle: float) -> list[Step]:
    steps = [
        Step(
            "STATIC_PRE",
            "static_pre",
            "NONE",
            "NONE",
            0.0,
            "1. 시작 전 정지 수집",
            "보드를 책상 위에 완전히 고정하세요. 시작하면 움직이지 말고 기다립니다.",
            static_seconds,
        )
    ]

    order = [
        ("X", "POS", "+X축 방향으로 360도"),
        ("X", "NEG", "-X축 방향으로 360도"),
        ("Y", "POS", "+Y축 방향으로 360도"),
        ("Y", "NEG", "-Y축 방향으로 360도"),
        ("Z", "POS", "+Z축 방향으로 360도"),
        ("Z", "NEG", "-Z축 방향으로 360도"),
    ]

    number = 2
    for axis, direction, text in order:
        for repeat in range(1, repeats + 1):
            trial_id = f"{axis}_{direction}_{repeat:02d}"
            steps.append(
                Step(
                    trial_id,
                    "rotation",
                    axis,
                    direction,
                    target_angle,
                    f"{number}. {text} 회전 {repeat}/{repeats}",
                    (
                        "회전축 하나만 고정해서 정확히 한 바퀴 돌립니다.\n"
                        "가능하면 지그, 모서리, 물리적 stop을 사용하세요.\n"
                        "준비되면 [수집 시작], 한 바퀴가 끝나면 [회전 완료]를 누릅니다."
                    ),
                )
            )
            number += 1

    steps.append(
        Step(
            "STATIC_POST",
            "static_post",
            "NONE",
            "NONE",
            0.0,
            f"{number}. 끝난 뒤 정지 수집",
            "모든 회전이 끝났습니다. 보드를 다시 완전히 정지시키고 기다립니다.",
            static_seconds,
        )
    )
    return steps


class SerialCsvWriter(threading.Thread):
    def __init__(self, port: str, baud: int, csv_path: Path, out_queue: queue.Queue):
        super().__init__(daemon=True)
        self.port = port
        self.baud = baud
        self.csv_path = csv_path
        self.out_queue = out_queue
        self.tx_queue: queue.Queue[str] = queue.Queue()
        self.stop_event = threading.Event()
        self.count = 0

    def send(self, command: str) -> None:
        self.tx_queue.put(command.strip() + "\n")

    def run(self) -> None:
        try:
            with serial.Serial(self.port, self.baud, timeout=0.05, write_timeout=0.2) as ser:
                time.sleep(1.5)
                ser.reset_input_buffer()
                self.out_queue.put(("status", f"{self.port} 연결됨"))
                with self.csv_path.open("w", newline="", encoding="utf-8") as file:
                    writer = csv.DictWriter(file, fieldnames=SAMPLE_COLUMNS)
                    writer.writeheader()

                    while not self.stop_event.is_set():
                        try:
                            command = self.tx_queue.get_nowait()
                        except queue.Empty:
                            command = ""
                        if command:
                            ser.write(command.encode("ascii"))
                            ser.flush()

                        raw = ser.readline()
                        if not raw:
                            continue
                        line = raw.decode("utf-8", errors="replace").strip()
                        if not line or line.startswith("#"):
                            continue
                        parts = next(csv.reader([line]))
                        if len(parts) != len(SAMPLE_COLUMNS):
                            self.out_queue.put(("serial", line))
                            continue
                        row = dict(zip(SAMPLE_COLUMNS, parts))
                        if row["record_type"] == "DATA":
                            writer.writerow(row)
                            file.flush()
                            self.count += 1
                            self.out_queue.put(("sample", self.count))
        except Exception as exc:
            self.out_queue.put(("error", str(exc)))

    def stop(self) -> None:
        self.stop_event.set()
        self.send("STOP")


class GyroCalibrationGui:
    def __init__(self, root: tk.Tk, port: str, baud: int, static_seconds: float, repeats: int):
        self.root = root
        self.port = port
        self.baud = baud
        self.static_seconds = static_seconds
        self.repeats = repeats
        self.steps = build_steps(repeats, static_seconds, TARGET_ANGLE_DEG)
        self.index = 0
        self.running = False
        self.auto_end_time = 0.0
        self.completed = False
        self.rx_queue: queue.Queue = queue.Queue()
        self.diagram_photo: tk.PhotoImage | None = None

        session_name = "gyro_" + datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_dir = SESSION_ROOT / session_name
        self.session_dir.mkdir(parents=True, exist_ok=False)
        self.csv_path = self.session_dir / "gyro_samples.csv"
        self.worker = SerialCsvWriter(port, baud, self.csv_path, self.rx_queue)

        self.root.title("Nano 33 BLE Rev2 Gyro Calibration")
        self.root.geometry("1200x960")
        self.root.configure(bg="#f5f7fb")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.title_label = tk.Label(root, text="", bg="#0f172a", fg="white", font=("Segoe UI", 22, "bold"), padx=18, pady=14)
        self.title_label.pack(fill="x")

        body = tk.Frame(root, bg="#f5f7fb")
        body.pack(fill="both", expand=True, padx=18, pady=18)

        self.guide_label = tk.Label(body, text="", bg="#ffffff", fg="#0f172a", justify="left", anchor="nw", wraplength=860, font=("Segoe UI", 16), padx=22, pady=22, relief="solid", bd=1)
        self.guide_label.pack(fill="x")

        self.diagram = tk.Canvas(body, height=600, bg="#000000", highlightthickness=0)
        self.diagram.pack(fill="x", pady=(12, 0))

        self.status_label = tk.Label(body, text="", bg="#f5f7fb", fg="#334155", justify="left", anchor="w", font=("Segoe UI", 13), pady=12)
        self.status_label.pack(fill="x")

        buttons = tk.Frame(body, bg="#f5f7fb")
        buttons.pack(fill="x", pady=8)
        self.start_button = tk.Button(buttons, text="수집 시작", command=self.start_step, font=("Segoe UI", 14, "bold"), height=2)
        self.start_button.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.stop_button = tk.Button(buttons, text="회전 완료 / 정지", command=self.stop_step, font=("Segoe UI", 14, "bold"), height=2, state="disabled")
        self.stop_button.pack(side="left", fill="x", expand=True, padx=8)
        self.skip_button = tk.Button(buttons, text="다음 단계", command=self.next_step, font=("Segoe UI", 14), height=2)
        self.skip_button.pack(side="left", fill="x", expand=True, padx=(8, 0))

        self.log_text = tk.Text(body, height=5, bg="#0f172a", fg="#cbd5e1", insertbackground="white", font=("Consolas", 10))
        self.log_text.pack(fill="both", expand=True, pady=(14, 0))

        self.worker.start()
        self.render()
        self.root.after(80, self.update_loop)

    def log(self, text: str) -> None:
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")

    def current_step(self) -> Step:
        return self.steps[self.index]

    def render(self) -> None:
        step = self.current_step()
        self.title_label.config(text=step.title)
        self.guide_label.config(text=step.guide)
        self.draw_diagram(step)
        progress = f"{self.index + 1} / {len(self.steps)}"
        state = "수집 중" if self.running else "대기"
        if self.running and step.auto_seconds > 0:
            remaining = max(0.0, self.auto_end_time - time.monotonic())
            state += f" ({remaining:.1f}초 남음)"
        self.status_label.config(
            text=(
                f"상태: {state}    단계: {progress}    포트: {self.port}@{self.baud}\n"
                f"저장 폴더: {self.session_dir}"
            )
        )
        self.start_button.config(state="disabled" if self.running else "normal")
        self.stop_button.config(state="normal" if self.running else "disabled")

    def draw_diagram(self, step: Step) -> None:
        self.diagram.delete("all")
        width = max(1120, self.diagram.winfo_width())
        height = max(600, self.diagram.winfo_height())
        self.diagram.create_rectangle(0, 0, width, height, fill="#000000", outline="")

        if step.phase != "rotation":
            self.draw_static_diagram(width, height, step)
            return

        image_path = self.rotation_image_path(step.axis, step.direction)
        if image_path.exists():
            self.diagram_photo = self.load_fitted_photo(image_path, width - 40, height - 36)
            self.diagram.create_image(width / 2, height / 2, image=self.diagram_photo, anchor="center")
            return

        sign = "+" if step.direction == "POS" else "-"
        title = f"{sign}{step.axis}축 360도 회전"
        self.diagram.create_text(
            width / 2,
            22,
            text=title,
            fill="#ffffff",
            font=("Segoe UI", 20, "bold"),
        )
        self.draw_board_top_view(80, 48, 320, 240, step.axis, step.direction)
        self.draw_side_view(500, 64, 420, 220, step.axis, step.direction)

        self.diagram.create_text(
            240,
            300,
            text=self.axis_hint(step.axis, step.direction),
            fill="#ffffff",
            font=("Segoe UI", 13, "bold"),
        )

    def rotation_image_path(self, axis: str, direction: str) -> Path:
        sign = "+" if direction == "POS" else "-"
        return PACKAGE_ROOT / f"{sign}{axis}축.png"

    def load_fitted_photo(self, path: Path, max_width: int, max_height: int) -> tk.PhotoImage:
        source = tk.PhotoImage(file=str(path))
        scale = max(
            1,
            math.ceil(source.width() / max_width),
            math.ceil(source.height() / max_height),
        )
        return source.subsample(scale, scale)
        self.diagram.create_text(
            720,
            300,
            text="화살표 방향으로 한 바퀴 회전한 뒤 [회전 완료 / 정지]",
            fill="#ffffff",
            font=("Segoe UI", 13, "bold"),
        )

    def draw_static_diagram(self, width: int, height: int, step: Step) -> None:
        self.diagram.create_text(
            width / 2,
            32,
            text=step.title,
            fill="#ffffff",
            font=("Segoe UI", 20, "bold"),
        )
        self.draw_board_top_view(width / 2 - 160, 66, 320, 220, "NONE", "NONE")
        self.diagram.create_text(
            width / 2,
            height - 34,
            text="보드를 책상 위에 완전히 고정하고 움직이지 마세요.",
            fill="#ffffff",
            font=("Segoe UI", 15, "bold"),
        )

    def draw_board_top_view(self, x: float, y: float, w: float, h: float, axis: str, direction: str) -> None:
        board = (x + 55, y + 28, x + w - 55, y + h - 16)
        bx1, by1, bx2, by2 = board
        cx = (bx1 + bx2) / 2
        cy = (by1 + by2) / 2
        arrow_color = "#0e6684"

        self.diagram.create_rectangle(bx1, by1, bx2, by2, fill="#ffffff", outline="#ffffff", width=2)
        self.diagram.create_rectangle(cx - 48, by1 - 30, cx + 48, by1 - 5, fill="#ffffff", outline="#ffffff")
        self.diagram.create_text(cx, by1 - 18, text="USB 연결부위", fill="#000000", font=("Segoe UI", 11, "bold"))
        self.diagram.create_rectangle(cx - 48, cy - 24, cx + 48, cy + 24, fill="#000000", outline=arrow_color, width=2)
        self.diagram.create_text(cx, cy, text="IMU칩", fill="#ffffff", font=("Segoe UI", 18, "bold"))
        self.diagram.create_text(bx1 - 28, cy, text="A side", fill="#ffffff", font=("Segoe UI", 10, "bold"))
        self.diagram.create_text(bx2 + 28, cy, text="D side", fill="#ffffff", font=("Segoe UI", 10, "bold"))

        if axis == "X":
            start_y = by1 + 42 if direction == "POS" else by2 - 20
            end_y = by2 - 20 if direction == "POS" else by1 + 42
            self.diagram.create_line(cx, start_y, cx, end_y, fill=arrow_color, width=6, arrow=tk.LAST, arrowshape=(18, 22, 8))
            self.diagram.create_text(cx + 38, end_y, text=f"{'+' if direction == 'POS' else '-'}X", fill="#000000" if end_y < by2 - 40 else "#ffffff", font=("Segoe UI", 14, "bold"))
        elif axis == "Y":
            start_x = bx1 + 28 if direction == "POS" else bx2 - 28
            end_x = bx2 - 28 if direction == "POS" else bx1 + 28
            self.diagram.create_line(start_x, cy, end_x, cy, fill=arrow_color, width=6, arrow=tk.LAST, arrowshape=(18, 22, 8))
            self.diagram.create_text(end_x, cy + 34, text=f"{'+' if direction == 'POS' else '-'}Y", fill="#000000", font=("Segoe UI", 14, "bold"))
        elif axis == "Z":
            self.diagram.create_oval(cx - 38, cy - 38, cx + 38, cy + 38, outline=arrow_color, width=5)
            if direction == "POS":
                self.diagram.create_oval(cx - 6, cy - 6, cx + 6, cy + 6, fill=arrow_color, outline=arrow_color)
                self.diagram.create_text(cx, cy + 66, text="+Z: 부품/글씨 면이 나를 향함", fill="#ffffff", font=("Segoe UI", 12, "bold"))
            else:
                self.diagram.create_line(cx - 16, cy - 16, cx + 16, cy + 16, fill=arrow_color, width=5)
                self.diagram.create_line(cx + 16, cy - 16, cx - 16, cy + 16, fill=arrow_color, width=5)
                self.diagram.create_text(cx, cy + 66, text="-Z: 부품/글씨 면이 바닥을 향함", fill="#ffffff", font=("Segoe UI", 12, "bold"))

    def draw_side_view(self, x: float, y: float, w: float, h: float, axis: str, direction: str) -> None:
        arrow_color = "#0e6684"
        cx = x + w / 2
        top = y + 116
        left = x + 70
        right = x + w - 70

        self.diagram.create_rectangle(left, top, right, top + 34, fill="#ffffff", outline="#ffffff")
        self.diagram.create_rectangle(left - 18, top + 34, left - 2, top + 100, fill="#d9d9d9", outline="#d9d9d9")
        self.diagram.create_rectangle(right + 2, top + 34, right + 18, top + 100, fill="#d9d9d9", outline="#d9d9d9")
        self.diagram.create_rectangle(cx - 50, top - 26, cx + 50, top - 8, outline=arrow_color, width=3)

        if axis in {"X", "Y"}:
            clockwise = direction == "POS"
            self.draw_arc_arrow(cx, top - 38, 90, clockwise, arrow_color)
            self.diagram.create_text(cx, top + 128, text=f"{'+' if direction == 'POS' else '-'}{axis}축 기준 회전", fill="#ffffff", font=("Segoe UI", 13, "bold"))
        elif axis == "Z":
            clockwise = direction == "POS"
            self.draw_arc_arrow(cx, top + 22, 92, clockwise, arrow_color)
            self.diagram.create_text(cx, top + 128, text=f"{'+' if direction == 'POS' else '-'}Z축 기준 평면 회전", fill="#ffffff", font=("Segoe UI", 13, "bold"))
        else:
            self.diagram.create_text(cx, top + 128, text="정지 수집", fill="#ffffff", font=("Segoe UI", 13, "bold"))

    def draw_arc_arrow(self, cx: float, cy: float, radius: float, clockwise: bool, color: str) -> None:
        import math

        if clockwise:
            angles = [210, 175, 140, 105, 70, 35, 8]
        else:
            angles = [8, 35, 70, 105, 140, 175, 210]

        points = []
        for angle in angles:
            rad = math.radians(angle)
            points.extend([cx + radius * math.cos(rad), cy + radius * math.sin(rad)])

        self.diagram.create_line(points, fill=color, width=5, smooth=True, arrow=tk.LAST, arrowshape=(18, 22, 8))

    def axis_hint(self, axis: str, direction: str) -> str:
        sign = "+" if direction == "POS" else "-"
        if axis == "X":
            return f"{sign}X: USB에서 반대쪽 edge로 향하는 축을 기준으로 회전"
        if axis == "Y":
            return f"{sign}Y: A side에서 D side로 향하는 축을 기준으로 회전"
        if axis == "Z":
            return f"{sign}Z: 부품/글씨 면의 앞뒤 방향 축을 기준으로 회전"
        return "정지 수집"

    def start_step(self) -> None:
        if self.running:
            return
        step = self.current_step()
        self.running = True
        self.auto_end_time = time.monotonic() + step.auto_seconds if step.auto_seconds > 0 else 0.0
        command = f"START {step.trial_id} {step.phase} {step.axis} {step.direction} {step.target_angle:.3f}"
        self.worker.send(command)
        self.log(f"START {step.trial_id}")
        self.render()

    def stop_step(self) -> None:
        if not self.running:
            return
        step = self.current_step()
        self.worker.send("STOP")
        self.running = False
        self.log(f"STOP {step.trial_id}")
        self.next_step()

    def next_step(self) -> None:
        if self.running:
            return
        if self.index < len(self.steps) - 1:
            self.index += 1
            self.render()
            return
        self.completed = True
        self.write_metadata()
        self.fit_and_apply()

    def fit_and_apply(self) -> None:
        time.sleep(0.3)
        try:
            result = fit_session(self.session_dir)
            (self.session_dir / "gyro_fit_result.json").write_text(
                json.dumps(result, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            apply_to_flex_config(result, dry_run=False)
        except Exception as exc:
            self.log("FIT/APPLY ERROR: " + str(exc))
            messagebox.showerror(
                "자동 반영 실패",
                (
                    f"수집 파일은 저장되었습니다:\n{self.session_dir}\n\n"
                    "자동 fit/apply 중 오류가 발생했습니다.\n"
                    "필요하면 아래 명령으로 다시 적용하세요:\n"
                    "python Gyro_Calibration/fit_and_apply_gyro_calibration.py\n\n"
                    f"오류: {exc}"
                ),
            )
            return

        self.log("FIT/APPLY 완료")
        self.log(f"bias: {result['static_bias_dps']}")
        self.log(f"scale: {result['gyro_scale']}")
        messagebox.showinfo(
            "자이로 calibration 완료",
            (
                f"수집 저장:\n{self.session_dir}\n\n"
                "자동 반영 완료:\n"
                "Test1_FlexSensor_Calibration/test1_flex_calibration.json\n"
                "Test1_FlexSensor/flex_config.h\n\n"
                "다음 단계: Test1_FlexSensor.ino를 업로드한 뒤 "
                "Flex calibration GUI를 실행하세요."
            ),
        )

    def write_metadata(self) -> None:
        metadata = {
            "schema_version": 1,
            "created_at_local": datetime.now().astimezone().isoformat(),
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "board": "Arduino Nano 33 BLE Rev2",
            "imu_library": "Arduino_BMI270_BMM150",
            "serial": {"port": self.port, "baud": self.baud},
            "csv": "gyro_samples.csv",
            "completed": self.completed,
            "protocol": {
                "static_seconds": self.static_seconds,
                "target_angle_deg": TARGET_ANGLE_DEG,
                "repeats_per_axis_direction": self.repeats,
                "rotation_trials": [
                    step.trial_id for step in self.steps if step.phase == "rotation"
                ],
            },
            "body_frame": {
                "x_positive": "USB connector edge toward the edge opposite USB",
                "y_positive": "A side toward D side",
                "z_positive": "component/label side outward",
                "handedness": "right-handed",
            },
        }
        (self.session_dir / "gyro_session.json").write_text(
            json.dumps(metadata, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def update_loop(self) -> None:
        try:
            while True:
                kind, value = self.rx_queue.get_nowait()
                if kind == "status":
                    self.log(str(value))
                elif kind == "sample":
                    if int(value) % 50 == 0:
                        self.log(f"samples: {value}")
                elif kind == "serial":
                    self.log(str(value))
                elif kind == "error":
                    self.log("ERROR: " + str(value))
        except queue.Empty:
            pass

        if self.running and self.current_step().auto_seconds > 0 and time.monotonic() >= self.auto_end_time:
            self.stop_step()

        self.render()
        self.root.after(80, self.update_loop)

    def on_close(self) -> None:
        try:
            self.worker.stop()
            self.worker.join(timeout=1.0)
        finally:
            if not (self.session_dir / "gyro_session.json").exists():
                self.write_metadata()
            self.root.destroy()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default=PORT)
    parser.add_argument("--baud", type=int, default=BAUD)
    parser.add_argument("--static-seconds", type=float, default=STATIC_SECONDS)
    parser.add_argument("--repeats", type=int, default=REPEATS)
    args = parser.parse_args()

    port = choose_serial_port(args.port)
    root = tk.Tk()
    GyroCalibrationGui(root, port, args.baud, args.static_seconds, args.repeats)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
