# Gyro Calibration

Nano 33 BLE Rev2의 자이로 bias와 scale을 계산하고 `Test1_FlexSensor`에 자동 반영하는 폴더입니다.

## 1. Raw Logger 업로드

Arduino IDE에서 아래 스케치를 엽니다.

```text
Gyro_Calibration/Gyro_RawLogger/Gyro_RawLogger.ino
```

보드는 `Arduino Nano 33 BLE Rev2`로 선택하고 업로드합니다.

## 2. GUI로 데이터 수집

```powershell
cd "업로드폴더"
python Gyro_Calibration/gyro_calibration_gui.py --port COM3
```

COM 번호는 환경에 맞게 바꿉니다.

GUI 단계:

- 시작 전 정지 수집
- +X 360도 회전
- -X 360도 회전
- +Y 360도 회전
- -Y 360도 회전
- +Z 360도 회전
- -Z 360도 회전
- 끝난 뒤 정지 수집

각 회전은 기본 3회 반복합니다.

회전 방향 그림:

```text
Gyro_Calibration/GYR_XYZ_Rotation_Process.png
```

## 3. Fit과 자동 반영

GUI 수집이 끝나면 자동으로 fit과 `Test1_FlexSensor` 반영까지 실행됩니다.

특정 session을 지정하려면:

```powershell
python Gyro_Calibration/fit_and_apply_gyro_calibration.py --session gyro_20260826_140500
```

생성/수정되는 파일:

```text
Gyro_Calibration/calibration_sessions/<session>/gyro_fit_result.json
Test1_FlexSensor_Calibration/test1_flex_calibration.json
Test1_FlexSensor/flex_config.h
```

## 계산 방식

정지 구간:

```text
gyro_bias = static_pre 평균
```

회전 구간:

```text
보정 전 각속도에서 bias 제거
각 trial을 시간 적분해서 실제 회전각 추정
scale = 목표 회전각 / 적분 회전각
축별 scale = accepted trial scale의 median
```

runtime 적용:

```cpp
gx = (rawGx - gyroBiasX) * GYRO_SCALE_X;
gy = (rawGy - gyroBiasY) * GYRO_SCALE_Y;
gz = (rawGz - gyroBiasZ) * GYRO_SCALE_Z;
```

## 주의

- Arduino Serial Monitor를 닫고 Python GUI를 실행하세요.
- 회전은 가능한 정확히 360도로 하세요.
- 손으로 돌릴 경우 오차가 커질 수 있으므로 지그나 물리적 stop을 사용하는 것이 좋습니다.
- GUI를 사용한 경우에는 수집 완료 시 자동 반영됩니다.
- 기존 session을 다시 적용할 때만 `fit_and_apply_gyro_calibration.py`를 따로 실행하세요.
