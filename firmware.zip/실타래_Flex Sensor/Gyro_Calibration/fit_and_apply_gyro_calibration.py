#!/usr/bin/env python3
"""Fit gyro calibration and apply it to Test1_FlexSensor.

This script reads a gyro calibration session made by Gyro_RawLogger.ino,
calculates bias and signed scale values, then writes:

- Gyro_Calibration/calibration_sessions/<session>/gyro_fit_result.json
- Test1_FlexSensor_Calibration/test1_flex_calibration.json
- Test1_FlexSensor/flex_config.h
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics as stats
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GYRO_DIR = ROOT / "Gyro_Calibration"
SESSION_ROOT = GYRO_DIR / "calibration_sessions"
FLEX_JSON = ROOT / "Test1_FlexSensor_Calibration" / "test1_flex_calibration.json"
FLEX_HEADER = ROOT / "Test1_FlexSensor" / "flex_config.h"

AXIS_TO_COLUMN = {
    "X": "gx_dps",
    "Y": "gy_dps",
    "Z": "gz_dps",
}


def mean(values: list[float]) -> float:
    if not values:
        raise ValueError("mean() received no values")
    return sum(values) / len(values)


def median(values: list[float]) -> float:
    if not values:
        raise ValueError("median() received no values")
    return float(stats.median(values))


def load_csv(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open("r", newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        for row in reader:
            if row.get("record_type") != "DATA":
                continue
            rows.append(row)
    if not rows:
        raise ValueError(f"No DATA rows found in {path}")
    return rows


def choose_session(requested: str | None) -> Path:
    if requested:
        path = Path(requested)
        if not path.is_absolute():
            path = SESSION_ROOT / requested
        if not path.exists():
            raise FileNotFoundError(path)
        return path

    sessions = [
        path for path in SESSION_ROOT.glob("gyro_*")
        if (path / "gyro_samples.csv").exists()
    ]
    if not sessions:
        raise FileNotFoundError(f"No gyro sessions under {SESSION_ROOT}")
    return max(sessions, key=lambda path: path.stat().st_mtime)


def compute_bias(rows: list[dict]) -> dict[str, float]:
    static_pre = [row for row in rows if row["phase"] == "static_pre"]
    static_post = [row for row in rows if row["phase"] == "static_post"]
    source = static_pre if static_pre else static_post
    if not source:
        raise ValueError("No static_pre/static_post rows found")

    return {
        "x": mean([float(row["gx_dps"]) for row in source]),
        "y": mean([float(row["gy_dps"]) for row in source]),
        "z": mean([float(row["gz_dps"]) for row in source]),
    }


def integrate_trial(rows: list[dict], axis: str, bias: dict[str, float]) -> float:
    column = AXIS_TO_COLUMN[axis]
    sorted_rows = sorted(rows, key=lambda row: int(row["t_us"]))
    total = 0.0

    for prev, cur in zip(sorted_rows, sorted_rows[1:]):
        dt_s = (int(cur["t_us"]) - int(prev["t_us"])) / 1_000_000.0
        if dt_s <= 0.0 or dt_s > 0.2:
            continue
        prev_value = float(prev[column]) - bias[axis.lower()]
        cur_value = float(cur[column]) - bias[axis.lower()]
        total += (prev_value + cur_value) * 0.5 * dt_s

    return total


def compute_scales(rows: list[dict], bias: dict[str, float]) -> tuple[dict[str, float], list[dict]]:
    grouped: dict[str, list[dict]] = {}
    for row in rows:
        if row["phase"] != "rotation":
            continue
        grouped.setdefault(row["trial_id"], []).append(row)

    per_trial: list[dict] = []
    scale_candidates: dict[str, list[float]] = {"X": [], "Y": [], "Z": []}

    for trial_id, trial_rows in sorted(grouped.items()):
        first = trial_rows[0]
        axis = first["axis"]
        direction = first["direction"]
        target_abs = float(first["target_angle_deg"])
        target_signed = target_abs if direction == "POS" else -target_abs
        integrated = integrate_trial(trial_rows, axis, bias)
        if abs(integrated) < target_abs * 0.15:
            accepted = False
            scale = 0.0
        else:
            accepted = True
            scale = target_signed / integrated
            scale_candidates[axis].append(scale)

        per_trial.append(
            {
                "trial_id": trial_id,
                "axis": axis,
                "direction": direction,
                "target_angle_deg": target_signed,
                "integrated_angle_deg": integrated,
                "scale": scale,
                "accepted": accepted,
            }
        )

    scales = {}
    for axis in ("X", "Y", "Z"):
        values = scale_candidates[axis]
        if not values:
            raise ValueError(f"No accepted rotation trials for axis {axis}")
        scales[axis.lower()] = median(values)

    return scales, per_trial


def float_literal(value: float, digits: int = 6) -> str:
    return f"{float(value):.{digits}f}f"


def render_flex_header(config: dict) -> str:
    left = config["flex"]["left"]
    right = config["flex"]["right"]
    imu = config["imu"]
    gesture = config["gesture"]
    return f"""#pragma once

#include <Arduino.h>

// Auto-generated by Gyro_Calibration/fit_and_apply_gyro_calibration.py
// Source JSON: Test1_FlexSensor_Calibration/test1_flex_calibration.json

constexpr float INITIAL_GYRO_BIAS_X = {float_literal(imu["gyro_bias_dps"]["x"], 9)};
constexpr float INITIAL_GYRO_BIAS_Y = {float_literal(imu["gyro_bias_dps"]["y"], 9)};
constexpr float INITIAL_GYRO_BIAS_Z = {float_literal(imu["gyro_bias_dps"]["z"], 9)};
constexpr float GYRO_SCALE_X = {float_literal(imu["gyro_scale"]["x"], 9)};
constexpr float GYRO_SCALE_Y = {float_literal(imu["gyro_scale"]["y"], 9)};
constexpr float GYRO_SCALE_Z = {float_literal(imu["gyro_scale"]["z"], 9)};
constexpr float CURSOR_DEADZONE_DPS = {float_literal(imu["cursor_deadzone_dps"], 4)};
constexpr float CURSOR_X_SENSITIVITY = {float_literal(imu["cursor_x_sensitivity"], 4)};
constexpr float CURSOR_Y_SENSITIVITY = {float_literal(imu["cursor_y_sensitivity"], 4)};
constexpr float MOUSE_X_SIGN = {float_literal(imu["mouse_x_sign"], 1)};
constexpr float MOUSE_Y_SIGN = {float_literal(imu["mouse_y_sign"], 1)};
constexpr float GYRO_LPF_ALPHA = {float_literal(imu["gyro_lpf_alpha"], 4)};
constexpr float CLICK_ALLOWED_MOTION_DPS = {float_literal(imu["click_allowed_motion_dps"], 4)};

constexpr int FLEX_ACTIVE_SIGN_LEFT = {int(left["active_sign"])};
constexpr int FLEX_ACTIVE_SIGN_RIGHT = {int(right["active_sign"])};
constexpr uint32_t FLEX_SAMPLE_INTERVAL_MS = 10;
constexpr uint32_t FLEX_SLOPE_WINDOW_MS = 120;
constexpr uint8_t FLEX_SLOPE_BUFFER_SIZE = 24;
constexpr uint32_t FLEX_BASELINE_CAPTURE_MS = 1500;
constexpr float FLEX_BASELINE_ALPHA = 0.0015f;
constexpr float FLEX_SLOPE_ALPHA = 0.35f;

constexpr int FLEX_PRESS_DELTA_LEFT = {int(left["press_delta"])};
constexpr int FLEX_RELEASE_DELTA_LEFT = {int(left["release_delta"])};
constexpr int FLEX_PRESS_DELTA_RIGHT = {int(right["press_delta"])};
constexpr int FLEX_RELEASE_DELTA_RIGHT = {int(right["release_delta"])};
constexpr float FLEX_PRESS_SLOPE_LEFT = {float_literal(left["press_slope_adc_per_s"], 3)};
constexpr float FLEX_PRESS_SLOPE_RIGHT = {float_literal(right["press_slope_adc_per_s"], 3)};
constexpr uint32_t FLEX_RELEASE_CONFIRM_MS = 90;
constexpr int FLEX_OPPOSITE_DELTA_MAX = {int(config["flex"]["opposite_delta_max"])};

constexpr uint32_t CLICK_MIN_HOLD_MS = {int(gesture["click_min_hold_ms"])};
constexpr uint32_t CLICK_MAX_HOLD_MS = {int(gesture["click_max_hold_ms"])};
constexpr uint32_t CLICK_FREEZE_MS = {int(gesture["click_freeze_ms"])};
constexpr uint32_t CLICK_REFRACTORY_MS = {int(gesture["click_refractory_ms"])};
constexpr uint32_t DUAL_PRESS_WINDOW_MS = {int(gesture["dual_press_window_ms"])};
constexpr uint32_t LONG_GESTURE_HOLD_MS = {int(gesture["long_gesture_hold_ms"])};
constexpr uint32_t DRAG_START_HOLD_MS = {int(gesture["drag_start_hold_ms"])};
constexpr uint32_t AXIS_SWAP_HOLD_MS = {int(gesture["axis_swap_hold_ms"])};
constexpr uint32_t DOUBLE_CLICK_GAP_MS = {int(gesture["double_click_gap_ms"])};
"""


def apply_to_flex_config(result: dict, dry_run: bool) -> None:
    if not FLEX_JSON.exists():
        raise FileNotFoundError(FLEX_JSON)

    config = json.loads(FLEX_JSON.read_text(encoding="utf-8-sig"))
    config.setdefault("imu", {})
    config["imu"]["gyro_bias_dps"] = result["static_bias_dps"]
    config["imu"]["gyro_scale"] = result["gyro_scale"]
    config["generated_at"] = datetime.now().isoformat(timespec="seconds")
    config["gyro_calibration_source"] = result["source_session"]

    if dry_run:
        return

    FLEX_JSON.write_text(
        json.dumps(config, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    FLEX_HEADER.write_text(render_flex_header(config), encoding="utf-8")


def fit_session(session_dir: Path) -> dict:
    rows = load_csv(session_dir / "gyro_samples.csv")
    bias = compute_bias(rows)
    scales, per_trial = compute_scales(rows, bias)
    result = {
        "schema_version": 1,
        "source_session": session_dir.name,
        "source_csv": "gyro_samples.csv",
        "fit_method": (
            "Bias from static_pre mean; signed scale from median of "
            "per-axis 360 degree rotation integrations after bias subtraction."
        ),
        "static_bias_dps": {
            "x": round(bias["x"], 9),
            "y": round(bias["y"], 9),
            "z": round(bias["z"], 9),
        },
        "gyro_scale": {
            "x": round(scales["x"], 9),
            "y": round(scales["y"], 9),
            "z": round(scales["z"], 9),
        },
        "trial_fit": per_trial,
        "runtime_formula": {
            "gx": "(raw_gx - bias_x) * scale_x",
            "gy": "(raw_gy - bias_y) * scale_y",
            "gz": "(raw_gz - bias_z) * scale_z",
        },
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--session",
        default=None,
        help="Session name or path. If omitted, the newest gyro_* session is used.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Fit and print only. Do not write JSON/header files.",
    )
    parser.add_argument(
        "--no-apply",
        action="store_true",
        help="Write gyro_fit_result.json but do not update Test1_FlexSensor.",
    )
    args = parser.parse_args()

    session_dir = choose_session(args.session)
    result = fit_session(session_dir)

    if not args.dry_run:
        (session_dir / "gyro_fit_result.json").write_text(
            json.dumps(result, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    if not args.no_apply:
        apply_to_flex_config(result, args.dry_run)

    print(f"Session: {session_dir}")
    print("Gyro bias dps:")
    for axis in ("x", "y", "z"):
        print(f"  {axis}: {result['static_bias_dps'][axis]: .9f}")
    print("Gyro scale:")
    for axis in ("x", "y", "z"):
        print(f"  {axis}: {result['gyro_scale'][axis]: .9f}")

    if args.dry_run:
        print("Dry run only. No files were written.")
    elif args.no_apply:
        print(f"Saved: {session_dir / 'gyro_fit_result.json'}")
    else:
        print(f"Saved: {session_dir / 'gyro_fit_result.json'}")
        print(f"Updated: {FLEX_JSON}")
        print(f"Updated: {FLEX_HEADER}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
