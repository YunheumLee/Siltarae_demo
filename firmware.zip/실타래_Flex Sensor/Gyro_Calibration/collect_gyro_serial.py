#!/usr/bin/env python3
"""Interactive collector for Gyro_RawLogger.ino.

Creates an ACC-style session directory containing:
- gyro_samples.csv
- gyro_session.json
"""

from __future__ import annotations

import argparse
import csv
import json
import queue
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import serial


SAMPLE_COLUMNS = [
    "record_type",
    "t_us",
    "trial_id",
    "phase",
    "axis",
    "direction",
    "target_angle_deg",
    "gx_dps",
    "gy_dps",
    "gz_dps",
    "event",
]


# ============================================================
# 사용자 설정
# ============================================================

# Arduino가 연결된 COM 포트로 변경하세요.
PORT = "COM17"

# Gyro_RawLogger.ino의 SERIAL_BAUD와 반드시 같아야 합니다.
BAUD = 115200

# 수집 결과가 저장될 폴더
SESSION_ROOT = "calibration_sessions"

# 시작/종료 정지 데이터 수집 시간
STATIC_SECONDS = 45.0

# 각 회전 trial의 실제 회전각
TARGET_ANGLE_DEG = 360.0

# X/Y/Z의 POS/NEG 방향별 반복 횟수
REPEATS = 3


def validate_pyserial() -> None:
    """serial 패키지가 pyserial인지 확인합니다."""

    if hasattr(serial, "Serial"):
        return

    imported_from = getattr(serial, "__file__", "unknown location")

    print(
        "ERROR: 현재 import된 serial 모듈은 pyserial이 아닙니다.",
        file=sys.stderr,
    )
    print(
        f"Imported from: {imported_from}",
        file=sys.stderr,
    )
    print("", file=sys.stderr)
    print("현재 Python 환경에서 다음 명령을 실행하세요:", file=sys.stderr)
    print("  python -m pip uninstall serial", file=sys.stderr)
    print("  python -m pip install --upgrade pyserial", file=sys.stderr)

    raise SystemExit(2)


class SerialCapture:
    def __init__(
        self,
        device: str,
        baud: int,
        output_dir: Path,
    ) -> None:

        self.serial_port = serial.Serial(
            device,
            baudrate=baud,
            timeout=0.25,
        )

        self.output_dir = output_dir
        self.stop_reader = threading.Event()
        self.errors: queue.Queue[str] = queue.Queue()

        self.thread = threading.Thread(
            target=self._reader,
            daemon=True,
        )

        self.samples_file = (
            output_dir / "gyro_samples.csv"
        ).open(
            "w",
            newline="",
            encoding="utf-8",
        )

        self.sample_writer = csv.DictWriter(
            self.samples_file,
            fieldnames=SAMPLE_COLUMNS,
        )

        self.sample_writer.writeheader()

    def start(self) -> None:
        """Arduino reset을 기다린 후 백그라운드 수신을 시작합니다."""

        time.sleep(1.5)

        self.serial_port.reset_input_buffer()
        self.thread.start()

    def send(self, command: str) -> None:
        """Arduino에 명령을 보냅니다."""

        self.serial_port.write(
            (command + "\n").encode("ascii")
        )
        self.serial_port.flush()

    def _reader(self) -> None:
        """Arduino 데이터를 계속 읽어 CSV에 저장합니다."""

        try:
            while not self.stop_reader.is_set():

                raw = self.serial_port.readline()

                if not raw:
                    continue

                line = raw.decode(
                    "utf-8",
                    errors="replace",
                ).rstrip("\r\n")

                if not line or line.startswith("#"):
                    continue

                row = next(csv.reader([line]))

                if len(row) != len(SAMPLE_COLUMNS):
                    self.errors.put(
                        "Unexpected CSV row "
                        f"({len(row)} fields): {line}"
                    )
                    continue

                record = dict(
                    zip(SAMPLE_COLUMNS, row)
                )

                if record["record_type"] == "DATA":

                    self.sample_writer.writerow(record)
                    self.samples_file.flush()

        except Exception as error:
            self.errors.put(repr(error))

    def close(self) -> None:
        """수신 스레드, CSV 파일, 시리얼 포트를 닫습니다."""

        self.stop_reader.set()
        self.thread.join(timeout=2.0)

        self.samples_file.close()
        self.serial_port.close()


def check_capture(capture: SerialCapture) -> None:
    """백그라운드 수신 중 발생한 오류를 확인합니다."""

    if not capture.errors.empty():
        raise RuntimeError(
            capture.errors.get()
        )


def static_trial(
    capture: SerialCapture,
    trial_id: str,
    phase: str,
    duration_s: float,
) -> None:
    """정지 상태 gyro 데이터를 수집합니다."""

    input(
        f"\n{trial_id}: "
        "보드를 완전히 정지시킨 뒤 Enter를 누르세요. "
    )

    capture.send(
        f"START {trial_id} {phase} NONE NONE 0"
    )

    print(
        f"  {duration_s:.0f}초 수집 중... "
        "보드를 절대 움직이지 마세요."
    )

    time.sleep(duration_s)

    capture.send("STOP")
    time.sleep(0.2)

    check_capture(capture)


def rotation_trial(
    capture: SerialCapture,
    trial_id: str,
    axis: str,
    direction: str,
    target_angle_deg: float,
) -> None:
    """한 번의 축 회전 trial을 수집합니다."""

    sign_text = "+" if direction == "POS" else "-"

    input(
        f"\n{trial_id}: "
        "회전축을 고정하고 준비한 뒤 Enter를 누르세요. "
        f"({sign_text}{target_angle_deg:.0f}° "
        f"about body {axis}) "
    )

    capture.send(
        f"START {trial_id} rotation "
        f"{axis} {direction} "
        f"{target_angle_deg:.3f}"
    )

    input(
        "  지금 정확히 한 바퀴 회전하세요. "
        "회전이 끝나면 완전히 정지한 뒤 Enter를 누르세요. "
    )

    capture.send("STOP")
    time.sleep(0.2)

    check_capture(capture)


def main() -> None:
    validate_pyserial()

    parser = argparse.ArgumentParser(
        description=(
            "Collect gyro calibration trials over serial."
        )
    )

    # 명령줄 인자는 선택 사항입니다.
    # 아무 인자 없이 Run 버튼을 누르면 위의 사용자 설정을 사용합니다.
    parser.add_argument(
        "--port",
        default=None,
        help=(
            "Arduino serial port. "
            f"If omitted, PORT='{PORT}' is used."
        ),
    )

    parser.add_argument(
        "--baud",
        type=int,
        default=None,
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=None,
    )

    parser.add_argument(
        "--static-seconds",
        type=float,
        default=None,
    )

    parser.add_argument(
        "--target-angle-deg",
        type=float,
        default=None,
    )

    parser.add_argument(
        "--repeats",
        type=int,
        default=None,
    )

    args = parser.parse_args()

    # 명령줄 값이 없으면 파일 상단의 사용자 설정을 사용합니다.
    if args.port is None:
        args.port = PORT

    if args.baud is None:
        args.baud = BAUD

    if args.output_root is None:
        args.output_root = Path(SESSION_ROOT)

    if args.static_seconds is None:
        args.static_seconds = STATIC_SECONDS

    if args.target_angle_deg is None:
        args.target_angle_deg = TARGET_ANGLE_DEG

    if args.repeats is None:
        args.repeats = REPEATS

    if args.static_seconds < 10:
        parser.error(
            "STATIC_SECONDS는 최소 10초 이상이어야 합니다."
        )

    if args.target_angle_deg <= 0:
        parser.error(
            "TARGET_ANGLE_DEG는 0보다 커야 합니다."
        )

    if args.repeats < 1:
        parser.error(
            "REPEATS는 1 이상이어야 합니다."
        )

    session_name = (
        "gyro_"
        + datetime.now().strftime("%Y%m%d_%H%M%S")
    )

    output_dir = (
        args.output_root / session_name
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    metadata = {
        "schema_version": 1,
        "created_at_local": (
            datetime.now()
            .astimezone()
            .isoformat()
        ),
        "created_at_utc": (
            datetime.now(timezone.utc)
            .isoformat()
        ),
        "board": "Arduino Nano 33 BLE Rev2",
        "imu_library": "Arduino_BMI270_BMM150",
        "serial": {
            "port": args.port,
            "baud": args.baud,
        },
        "csv": "gyro_samples.csv",
        "protocol": {
            "static_seconds": args.static_seconds,
            "target_angle_deg": args.target_angle_deg,
            "repeats_per_axis_direction": (
                args.repeats
            ),
            "rotation_trials": [
                f"{axis}_{direction}_{repeat:02d}"
                for axis in ("X", "Y", "Z")
                for direction in ("POS", "NEG")
                for repeat in range(
                    1,
                    args.repeats + 1,
                )
            ],
        },
        "body_frame": {
            "x_positive": (
                "USB connector edge toward "
                "the edge opposite USB"
            ),
            "y_positive": (
                "A side toward D side"
            ),
            "z_positive": (
                "component/label side outward"
            ),
            "handedness": "right-handed",
        },
    }

    print("")
    print(
        f"Opening {args.port} "
        f"at {args.baud} baud"
    )
    print(
        f"Session directory: "
        f"{output_dir.resolve()}"
    )
    print(
        "Arduino Serial Monitor를 닫은 상태에서 "
        "실행해야 합니다."
    )

    capture = SerialCapture(
        args.port,
        args.baud,
        output_dir,
    )

    completed = False

    try:
        capture.start()

        print("")
        print(
            "회전각은 눈대중으로 맞추지 말고 "
            "가능하면 지그 또는 물리적 stop을 사용하세요."
        )

        # 시작 전 정지 데이터
        static_trial(
            capture,
            "STATIC_PRE",
            "static_pre",
            args.static_seconds,
        )

        # X/Y/Z축, POS/NEG 방향별 반복 수집
        for axis in ("X", "Y", "Z"):

            for direction in ("POS", "NEG"):

                for repeat in range(
                    1,
                    args.repeats + 1,
                ):
                    trial_id = (
                        f"{axis}_{direction}_{repeat:02d}"
                    )

                    rotation_trial(
                        capture,
                        trial_id,
                        axis,
                        direction,
                        args.target_angle_deg,
                    )

        # 전체 회전이 끝난 후 정지 데이터
        static_trial(
            capture,
            "STATIC_POST",
            "static_post",
            args.static_seconds,
        )

        completed = True

    except KeyboardInterrupt:
        print("")
        print(
            "사용자가 중단했습니다. "
            "부분 파일은 남지만 fitting에 사용하지 마세요."
        )

    finally:
        try:
            capture.send("STOP")

        except serial.SerialException:
            pass

        capture.close()

    metadata["completed"] = completed

    metadata_path = (
        output_dir / "gyro_session.json"
    )

    metadata_path.write_text(
        json.dumps(
            metadata,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    print("")
    print(
        f"Saved session: {output_dir.resolve()}"
    )
    print(
        f"Metadata: {metadata_path.resolve()}"
    )

    if completed:
        print(
            "수집 완료. 다음 단계에서 "
            "fit_and_apply_gyro_calibration.py를 실행하세요."
        )
    else:
        print(
            "수집이 완료되지 않았습니다. "
            "이 세션은 fitting에 사용하지 마세요."
        )


if __name__ == "__main__":
    main()
