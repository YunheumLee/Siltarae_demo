#include <Arduino_BMI270_BMM150.h>

// Nano 33 BLE Rev2 gyro raw logger.
//
// The board does not calculate calibration values.  It only emits raw gyro
// samples while Python assigns trials and performs all fitting.
//
// Serial command:
//   START <trial_id> <phase> <axis> <direction> <target_angle_deg>
//   STOP
//   STATUS
//   HELP
//
// Example:
//   START X_POS_01 rotation X POS 360
//   STOP

//const unsigned long SERIAL_BAUD = 230400;

const unsigned long SERIAL_BAUD = 115200;

bool recording = false;
String trialId = "NONE";
String phase = "idle";
String axisName = "NONE";
String directionName = "NONE";
float targetAngleDeg = 0.0f;

String nextToken(String &text) {
  text.trim();
  int separator = text.indexOf(' ');
  if (separator < 0) {
    String token = text;
    text = "";
    return token;
  }
  String token = text.substring(0, separator);
  text = text.substring(separator + 1);
  text.trim();
  return token;
}

void emitEvent(const char *name) {
  Serial.print("EVENT,");
  Serial.print(micros());
  Serial.print(',');
  Serial.print(trialId);
  Serial.print(',');
  Serial.print(phase);
  Serial.print(',');
  Serial.print(axisName);
  Serial.print(',');
  Serial.print(directionName);
  Serial.print(',');
  Serial.print(targetAngleDeg, 3);
  Serial.print(",,,,");
  Serial.print(name);
  Serial.println();
}

void printHelp() {
  Serial.println("# Commands:");
  Serial.println("# START <trial_id> <phase> <axis> <direction> <target_angle_deg>");
  Serial.println("# STOP | STATUS | HELP");
  Serial.println("# axis: X/Y/Z/NONE, direction: POS/NEG/NONE");
}

void startRecording(String line) {
  String command = nextToken(line);
  String newTrialId = nextToken(line);
  String newPhase = nextToken(line);
  String newAxis = nextToken(line);
  String newDirection = nextToken(line);
  String angleText = nextToken(line);

  if (command != "START" || newTrialId.length() == 0 || newPhase.length() == 0 ||
      newAxis.length() == 0 || newDirection.length() == 0 || angleText.length() == 0) {
    Serial.println("# ERROR: START requires 5 arguments.");
    return;
  }

  trialId = newTrialId;
  phase = newPhase;
  axisName = newAxis;
  directionName = newDirection;
  targetAngleDeg = angleText.toFloat();
  recording = true;
  emitEvent("START");
}

void serviceSerial() {
  if (!Serial.available()) return;

  String line = Serial.readStringUntil('\n');
  line.trim();
  if (line.length() == 0) return;

  if (line.startsWith("START ")) {
    startRecording(line);
  } else if (line == "STOP") {
    if (recording) emitEvent("STOP");
    recording = false;
  } else if (line == "STATUS") {
    emitEvent(recording ? "RECORDING" : "IDLE");
  } else if (line == "HELP") {
    printHelp();
  } else {
    Serial.println("# ERROR: unknown command. Send HELP.");
  }
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  while (!Serial) {
    ;
  }

  if (!IMU.begin()) {
    Serial.println("# ERROR: Failed to initialize Arduino_BMI270_BMM150.");
    while (true) {
      ;
    }
  }

  Serial.println("# Nano 33 BLE Rev2 gyro raw logger ready");
  Serial.println("record_type,t_us,trial_id,phase,axis,direction,target_angle_deg,gx_dps,gy_dps,gz_dps,event");
  printHelp();
}

void loop() {
  serviceSerial();

  if (!recording || !IMU.gyroscopeAvailable()) return;

  float gx, gy, gz;
  IMU.readGyroscope(gx, gy, gz);

  Serial.print("DATA,");
  Serial.print(micros());
  Serial.print(',');
  Serial.print(trialId);
  Serial.print(',');
  Serial.print(phase);
  Serial.print(',');
  Serial.print(axisName);
  Serial.print(',');
  Serial.print(directionName);
  Serial.print(',');
  Serial.print(targetAngleDeg, 3);
  Serial.print(',');
  Serial.print(gx, 6);
  Serial.print(',');
  Serial.print(gy, 6);
  Serial.print(',');
  Serial.print(gz, 6);
  Serial.println(",");
}
