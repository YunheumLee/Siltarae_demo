@echo off
cd /d "%~dp0"
python -m pip install --upgrade pyinstaller
python -m PyInstaller --noconsole --onefile --name AirMouse_Setup_App --distpath . --workpath build --specpath build AirMouse_Setup_App.py
echo.
echo Build complete: AirMouse_Setup_App.exe
pause
