@echo off
cd /d "%~dp0"
python AirMouse_Setup_App.py
if errorlevel 1 (
  py -3 AirMouse_Setup_App.py
)
pause
