# Test1 FlexSensor Runtime

최종 BLE 마우스 Arduino 스케치입니다.

```text
Test1_FlexSensor/Test1_FlexSensor.ino
```

BLE 이름:

```text
Nano Flex Mouse T1
```

## 입력

- A0: 좌클릭용 Flex sensor
- A1: 우클릭용 Flex sensor
- IMU gyro: 마우스 커서 이동

## Gesture

- A0 짧게 구부렸다 펴기: 좌클릭
- A1 짧게 구부렸다 펴기: 우클릭
- A0 오래 유지 후 펴기: 더블클릭
- A1 오래 유지: 드래그 시작
- 드래그 중 A1 펴기: 드롭
- A0 + A1 오래 유지: 마우스 X/Y 방향 부호 반전

## 설정 파일

아래 파일은 calibration script가 자동 생성합니다.

```text
Test1_FlexSensor/flex_config.h
```

직접 수정하기보다 다음 GUI와 script를 사용하는 것을 권장합니다.

```text
Gyro_Calibration/fit_and_apply_gyro_calibration.py
Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py
```

## Serial 명령

USB Serial로 임시 조절할 수 있습니다.

```text
SX=120   수평 감도
SY=140   수직 감도
DZ=0.7   deadzone
PRINT    현재 설정 출력
STREAM=1 calibration GUI용 raw stream
STREAM=0 raw stream 중지
```

`BIAS` 명령도 코드에는 남아 있지만, 정밀 gyro calibration을 사용하는 경우 권장하지 않습니다.
gyro bias/scale은 `Gyro_Calibration/fit_and_apply_gyro_calibration.py`로 반영하세요.
