#include <Arduino.h>
#include <Arduino_BMI270_BMM150.h>
#include <HIDMouse.h>
#include <stdlib.h>
#include <string.h>
#include "flex_config.h"

// ============================================================
// Test1_FlexSensor: single-runtime Nano 33 BLE Rev2 assistive air mouse
//
// Gestures:
// - A0 short press/release: left click
// - A1 short press/release: right click
// - A0 long press/release: left double click
// - A1 long hold: drag start
// - A1 release while dragging: drop
// - A0 + A1 hold: invert mouse X/Y directions
//
// Flex sensor method:
// - calibrated slope catches A0/A1 press starts
// - calibrated delta is used only to hold/release the press state
// - X/Y cursor directions are reversed in flex_config.h for this wiring
// - IMU cursor sensitivity can be tuned at runtime through USB Serial
// ============================================================

HIDMouse bleMouse;

constexpr uint8_t MOUSE_LEFT_BUTTON = 0x01;
constexpr uint8_t MOUSE_RIGHT_BUTTON = 0x02;
constexpr int MAX_MOUSE_STEP = 127;

constexpr uint8_t PIN_FLEX_LEFT = A0;
constexpr uint8_t PIN_FLEX_RIGHT = A1;

constexpr bool PRINT_DEBUG = false;
constexpr uint32_t DEBUG_INTERVAL_MS = 100;
constexpr uint32_t DEBUG_SERIAL_WAIT_MS = 1500;
constexpr uint8_t SERIAL_COMMAND_BUFFER_SIZE = 48;
constexpr uint32_t CALIBRATION_STREAM_INTERVAL_MS = 20;

float gyroBiasX = INITIAL_GYRO_BIAS_X;
float gyroBiasY = INITIAL_GYRO_BIAS_Y;
float gyroBiasZ = INITIAL_GYRO_BIAS_Z;
float cursorDeadzoneDps = CURSOR_DEADZONE_DPS;
float cursorXSensitivity = CURSOR_X_SENSITIVITY;
float cursorYSensitivity = CURSOR_Y_SENSITIVITY;
float gyroLpfAlpha = GYRO_LPF_ALPHA;
float clickAllowedMotionDps = CLICK_ALLOWED_MOTION_DPS;
bool debugOutputEnabled = PRINT_DEBUG;
bool calibrationStreamEnabled = false;
uint32_t lastCalibrationStreamMs = 0;
float latestRawGx = 0.0f;
float latestRawGy = 0.0f;
float latestRawGz = 0.0f;

enum FingerId
{
    FINGER_NONE,
    FINGER_LEFT,
    FINGER_RIGHT
};

enum ControlMode
{
    MODE_IDLE,
    MODE_ONE_FINGER_DOWN,
    MODE_SIGN_INVERT_ARMED,
    MODE_DRAGGING,
    MODE_CLICK_FREEZE,
    MODE_WAIT_ALL_RELEASE
};

struct FlexSensor
{
    const char *name;
    uint8_t pin;
    int activeSign;
    int pressDelta;
    int releaseDelta;
    float pressSlope;
    int raw;
    int signedDelta;
    float baseline;
    float slope;
    bool pressed;
    bool pressedEdge;
    bool releasedEdge;
    bool releaseCandidate;
    uint32_t pressedAtMs;
    uint32_t releaseCandidateSinceMs;
    uint32_t lastSampleMs;
    int valueWindow[FLEX_SLOPE_BUFFER_SIZE];
    uint32_t timeWindow[FLEX_SLOPE_BUFFER_SIZE];
    uint8_t windowIndex;
    uint8_t windowCount;
};

FlexSensor leftSensor =
{
    "LEFT",
    PIN_FLEX_LEFT,
    FLEX_ACTIVE_SIGN_LEFT,
    FLEX_PRESS_DELTA_LEFT,
    FLEX_RELEASE_DELTA_LEFT,
    FLEX_PRESS_SLOPE_LEFT,
    0,
    0,
    0.0f,
    0.0f,
    false,
    false,
    false,
    false,
    0,
    0,
    0,
    {0},
    {0},
    0,
    0
};

FlexSensor rightSensor =
{
    "RIGHT",
    PIN_FLEX_RIGHT,
    FLEX_ACTIVE_SIGN_RIGHT,
    FLEX_PRESS_DELTA_RIGHT,
    FLEX_RELEASE_DELTA_RIGHT,
    FLEX_PRESS_SLOPE_RIGHT,
    0,
    0,
    0.0f,
    0.0f,
    false,
    false,
    false,
    false,
    0,
    0,
    0,
    {0},
    {0},
    0,
    0
};

ControlMode controlMode = MODE_IDLE;
FingerId activeFinger = FINGER_NONE;
uint32_t gestureStartMs = 0;
uint32_t freezeUntilMs = 0;
uint32_t lastClickMs = 0;
bool dragButtonDown = false;
bool cursorSignsInverted = false;
uint32_t signInvertStartedMs = 0;

float filteredGx = 0.0f;
float filteredGy = 0.0f;
float filteredGz = 0.0f;
float mouseAccumX = 0.0f;
float mouseAccumY = 0.0f;
int lastMouseDx = 0;
int lastMouseDy = 0;
float gyroMotionDps = 0.0f;
bool clickMotionTooLarge = false;
uint32_t previousTimeUs = 0;

const char *modeName(ControlMode mode)
{
    switch (mode)
    {
        case MODE_IDLE: return "IDLE";
        case MODE_ONE_FINGER_DOWN: return "ONE_FINGER_DOWN";
        case MODE_SIGN_INVERT_ARMED: return "SIGN_INVERT_ARMED";
        case MODE_DRAGGING: return "DRAGGING";
        case MODE_CLICK_FREEZE: return "CLICK_FREEZE";
        case MODE_WAIT_ALL_RELEASE: return "WAIT_ALL_RELEASE";
    }

    return "UNKNOWN";
}

float signOf(float value)
{
    if (value > 0.0f)
    {
        return 1.0f;
    }

    if (value < 0.0f)
    {
        return -1.0f;
    }

    return 0.0f;
}

float shapeGyro(float value, float deadzone)
{
    float absValue = fabs(value);

    if (absValue < deadzone)
    {
        return 0.0f;
    }

    return signOf(value) * (absValue - deadzone);
}

FlexSensor &sensorForFinger(FingerId finger)
{
    return (finger == FINGER_RIGHT) ? rightSensor : leftSensor;
}

uint8_t mouseButtonForFinger(FingerId finger)
{
    return (finger == FINGER_RIGHT) ? MOUSE_RIGHT_BUTTON : MOUSE_LEFT_BUTTON;
}

float captureBaseline(uint8_t pin)
{
    uint32_t startMs = millis();
    long sum = 0;
    int count = 0;

    while (millis() - startMs < FLEX_BASELINE_CAPTURE_MS)
    {
        sum += analogRead(pin);
        count++;
        delay(FLEX_SAMPLE_INTERVAL_MS);
    }

    if (count <= 0)
    {
        return (float)analogRead(pin);
    }

    return (float)sum / (float)count;
}

void setMode(ControlMode mode)
{
    if (controlMode == mode)
    {
        return;
    }

    controlMode = mode;

    if (debugOutputEnabled && Serial)
    {
        Serial.print("MODE ");
        Serial.println(modeName(controlMode));
    }
}

void initFlexSensor(FlexSensor &sensor)
{
    pinMode(sensor.pin, INPUT);
    sensor.baseline = captureBaseline(sensor.pin);
    sensor.raw = analogRead(sensor.pin);
    sensor.signedDelta = 0;
    sensor.slope = 0.0f;
    sensor.pressed = false;
    sensor.pressedEdge = false;
    sensor.releasedEdge = false;
    sensor.releaseCandidate = false;
    sensor.pressedAtMs = 0;
    sensor.releaseCandidateSinceMs = 0;
    sensor.lastSampleMs = millis();
    sensor.windowIndex = 0;
    sensor.windowCount = 0;

    for (uint8_t i = 0; i < FLEX_SLOPE_BUFFER_SIZE; i++)
    {
        sensor.valueWindow[i] = sensor.raw;
        sensor.timeWindow[i] = sensor.lastSampleMs;
    }

    if (debugOutputEnabled && Serial)
    {
        Serial.print(sensor.name);
        Serial.print(" baseline ");
        Serial.println(sensor.baseline, 1);
    }
}

void resetReleaseCandidate(FlexSensor &sensor)
{
    sensor.releaseCandidate = false;
    sensor.releaseCandidateSinceMs = 0;
}

void updateFlexSensor(FlexSensor &sensor)
{
    sensor.pressedEdge = false;
    sensor.releasedEdge = false;

    uint32_t nowMs = millis();
    uint32_t elapsedMs = nowMs - sensor.lastSampleMs;

    if (elapsedMs < FLEX_SAMPLE_INTERVAL_MS)
    {
        return;
    }

    int newRaw = analogRead(sensor.pin);
    sensor.raw = newRaw;
    sensor.signedDelta = sensor.activeSign * (sensor.raw - (int)sensor.baseline);

    sensor.valueWindow[sensor.windowIndex] = newRaw;
    sensor.timeWindow[sensor.windowIndex] = nowMs;
    sensor.windowIndex = (sensor.windowIndex + 1) % FLEX_SLOPE_BUFFER_SIZE;

    if (sensor.windowCount < FLEX_SLOPE_BUFFER_SIZE)
    {
        sensor.windowCount++;
    }

    uint8_t oldestIndex =
        (sensor.windowIndex + FLEX_SLOPE_BUFFER_SIZE - sensor.windowCount)
        % FLEX_SLOPE_BUFFER_SIZE;

    for (uint8_t i = 0; i < sensor.windowCount; i++)
    {
        uint8_t index =
            (sensor.windowIndex + FLEX_SLOPE_BUFFER_SIZE - 1 - i)
            % FLEX_SLOPE_BUFFER_SIZE;

        if (nowMs - sensor.timeWindow[index] >= FLEX_SLOPE_WINDOW_MS)
        {
            oldestIndex = index;
            break;
        }
    }

    int windowDelta =
        sensor.activeSign * (newRaw - sensor.valueWindow[oldestIndex]);
    uint32_t windowElapsedMs = nowMs - sensor.timeWindow[oldestIndex];

    if (windowElapsedMs <= 0)
    {
        windowElapsedMs = elapsedMs;
    }

    float windowSlope =
        ((float)windowDelta * 1000.0f) / (float)windowElapsedMs;
    sensor.slope += (windowSlope - sensor.slope) * FLEX_SLOPE_ALPHA;
    sensor.lastSampleMs = nowMs;

    if (!sensor.pressed)
    {
        bool quiet =
            abs(sensor.signedDelta) <= sensor.releaseDelta &&
            fabs(sensor.slope) < (sensor.pressSlope * 0.35f);

        if (quiet)
        {
            sensor.baseline +=
                ((float)sensor.raw - sensor.baseline) *
                FLEX_BASELINE_ALPHA;
        }

        bool slopePress =
            sensor.slope >= sensor.pressSlope;
        bool deltaPress =
            sensor.signedDelta >= sensor.pressDelta;

        if (slopePress || deltaPress)
        {
            sensor.pressed = true;
            sensor.pressedEdge = true;
            sensor.pressedAtMs = nowMs;
            resetReleaseCandidate(sensor);
        }

        return;
    }

    bool releaseNow = sensor.signedDelta <= sensor.releaseDelta;

    if (releaseNow)
    {
        if (!sensor.releaseCandidate)
        {
            sensor.releaseCandidate = true;
            sensor.releaseCandidateSinceMs = nowMs;
        }

        if (nowMs - sensor.releaseCandidateSinceMs >= FLEX_RELEASE_CONFIRM_MS)
        {
            sensor.pressed = false;
            sensor.releasedEdge = true;
            resetReleaseCandidate(sensor);
        }
    }
    else
    {
        resetReleaseCandidate(sensor);
    }
}

void updateAllFlexSensors()
{
    updateFlexSensor(leftSensor);
    updateFlexSensor(rightSensor);
}

bool readCorrectedGyro(float &gx, float &gy, float &gz)
{
    if (!IMU.gyroscopeAvailable())
    {
        return false;
    }

    float rawGx;
    float rawGy;
    float rawGz;

    if (!IMU.readGyroscope(rawGx, rawGy, rawGz))
    {
        return false;
    }

    latestRawGx = rawGx;
    latestRawGy = rawGy;
    latestRawGz = rawGz;

    gx = (rawGx - gyroBiasX) * GYRO_SCALE_X;
    gy = (rawGy - gyroBiasY) * GYRO_SCALE_Y;
    gz = (rawGz - gyroBiasZ) * GYRO_SCALE_Z;

    filteredGx += (gx - filteredGx) * gyroLpfAlpha;
    filteredGy += (gy - filteredGy) * gyroLpfAlpha;
    filteredGz += (gz - filteredGz) * gyroLpfAlpha;

    gx = filteredGx;
    gy = filteredGy;
    gz = filteredGz;

    gyroMotionDps = sqrt(gx * gx + gy * gy + gz * gz);
    clickMotionTooLarge = gyroMotionDps > clickAllowedMotionDps;
    return true;
}

bool allReleased()
{
    return !leftSensor.pressed && !rightSensor.pressed;
}

bool bothPressed()
{
    return leftSensor.pressed && rightSensor.pressed;
}

void enterOneFinger(FingerId finger)
{
    activeFinger = finger;
    gestureStartMs = millis();
    mouseAccumX = 0.0f;
    mouseAccumY = 0.0f;
    setMode(MODE_ONE_FINGER_DOWN);
}

void enterSignInvertArmed()
{
    activeFinger = FINGER_NONE;
    signInvertStartedMs = millis();
    mouseAccumX = 0.0f;
    mouseAccumY = 0.0f;
    setMode(MODE_SIGN_INVERT_ARMED);
}

void toggleSignInvertMode()
{
    cursorSignsInverted = !cursorSignsInverted;
    resetCursorOutput();
    resetGyroFilter();
    lastClickMs = millis();
    setMode(MODE_WAIT_ALL_RELEASE);

    if (debugOutputEnabled && Serial)
    {
        Serial.print("SIGN_INVERT ");
        Serial.println(cursorSignsInverted ? 1 : 0);
    }
}

void enterClickFreeze()
{
    freezeUntilMs = millis() + CLICK_FREEZE_MS;
    mouseAccumX = 0.0f;
    mouseAccumY = 0.0f;
    setMode(MODE_CLICK_FREEZE);
}

void sendClick(FingerId finger, uint8_t count)
{
    if (bleMouse.isConnected())
    {
        for (uint8_t i = 0; i < count; i++)
        {
            bleMouse.click(mouseButtonForFinger(finger));

            if (i + 1 < count)
            {
                delay(DOUBLE_CLICK_GAP_MS);
            }
        }
    }

    lastClickMs = millis();
    enterClickFreeze();
}

void startDrag()
{
    if (bleMouse.isConnected() && !dragButtonDown)
    {
        bleMouse.press(MOUSE_LEFT_BUTTON);
        dragButtonDown = true;
    }

    mouseAccumX = 0.0f;
    mouseAccumY = 0.0f;
    setMode(MODE_DRAGGING);
}

void stopDrag()
{
    if (bleMouse.isConnected() && dragButtonDown)
    {
        bleMouse.release(MOUSE_LEFT_BUTTON);
    }

    dragButtonDown = false;
    lastClickMs = millis();
    enterClickFreeze();
}

void handleGestureState()
{
    uint32_t nowMs = millis();

    if (controlMode == MODE_CLICK_FREEZE)
    {
        if (nowMs >= freezeUntilMs)
        {
            setMode(MODE_IDLE);
        }

        return;
    }

    if (controlMode == MODE_WAIT_ALL_RELEASE)
    {
        if (allReleased())
        {
            setMode(MODE_IDLE);
        }

        return;
    }

    if (controlMode == MODE_DRAGGING)
    {
        if (!rightSensor.pressed)
        {
            stopDrag();
        }

        return;
    }

    if (controlMode == MODE_SIGN_INVERT_ARMED)
    {
        if (!bothPressed())
        {
            setMode(MODE_WAIT_ALL_RELEASE);
            return;
        }

        if (nowMs - signInvertStartedMs >= AXIS_SWAP_HOLD_MS)
        {
            toggleSignInvertMode();
        }

        return;
    }

    if (controlMode == MODE_IDLE)
    {
        if (bothPressed())
        {
            enterSignInvertArmed();
            return;
        }

        bool refractoryDone = (nowMs - lastClickMs >= CLICK_REFRACTORY_MS);

        if (!refractoryDone || clickMotionTooLarge)
        {
            return;
        }

        if (
            leftSensor.pressedEdge &&
            !rightSensor.pressed &&
            abs(rightSensor.signedDelta) <= FLEX_OPPOSITE_DELTA_MAX
        )
        {
            enterOneFinger(FINGER_LEFT);
        }
        else if (
            rightSensor.pressedEdge &&
            !leftSensor.pressed &&
            abs(leftSensor.signedDelta) <= FLEX_OPPOSITE_DELTA_MAX
        )
        {
            enterOneFinger(FINGER_RIGHT);
        }

        return;
    }

    if (controlMode != MODE_ONE_FINGER_DOWN)
    {
        return;
    }

    FlexSensor &sensor = sensorForFinger(activeFinger);
    uint32_t holdMs = nowMs - gestureStartMs;

    if (
        bothPressed() &&
        holdMs <= DUAL_PRESS_WINDOW_MS
    )
    {
        enterSignInvertArmed();
        return;
    }

    if (
        activeFinger == FINGER_RIGHT &&
        holdMs >= DRAG_START_HOLD_MS
    )
    {
        startDrag();
        return;
    }

    if (!sensor.releasedEdge)
    {
        return;
    }

    if (
        activeFinger == FINGER_LEFT &&
        holdMs >= LONG_GESTURE_HOLD_MS
    )
    {
        sendClick(FINGER_LEFT, 2);
        return;
    }

    bool validShortClick =
        holdMs >= CLICK_MIN_HOLD_MS &&
        holdMs <= CLICK_MAX_HOLD_MS;

    if (validShortClick)
    {
        sendClick(activeFinger, 1);
    }
    else
    {
        activeFinger = FINGER_NONE;
        setMode(MODE_WAIT_ALL_RELEASE);
    }
}

bool outputLocked()
{
    return
        controlMode == MODE_ONE_FINGER_DOWN ||
        controlMode == MODE_SIGN_INVERT_ARMED ||
        controlMode == MODE_CLICK_FREEZE ||
        controlMode == MODE_WAIT_ALL_RELEASE;
}

void resetCursorOutput()
{
    mouseAccumX = 0.0f;
    mouseAccumY = 0.0f;
    lastMouseDx = 0;
    lastMouseDy = 0;
}

void resetGyroFilter()
{
    filteredGx = 0.0f;
    filteredGy = 0.0f;
    filteredGz = 0.0f;
}

void emitCursor(float gx, float gz, float dt)
{
    float directionSign = cursorSignsInverted ? -1.0f : 1.0f;
    float horizontal = directionSign * MOUSE_X_SIGN * shapeGyro(gz, cursorDeadzoneDps);
    float vertical = directionSign * MOUSE_Y_SIGN * shapeGyro(gx, cursorDeadzoneDps);

    mouseAccumX += horizontal * dt * cursorXSensitivity;
    mouseAccumY += vertical * dt * cursorYSensitivity;

    int dx = constrain((int)mouseAccumX, -MAX_MOUSE_STEP, MAX_MOUSE_STEP);
    int dy = constrain((int)mouseAccumY, -MAX_MOUSE_STEP, MAX_MOUSE_STEP);
    lastMouseDx = dx;
    lastMouseDy = dy;

    if (dx != 0 || dy != 0)
    {
        if (bleMouse.isConnected())
        {
            bleMouse.move(dx, dy, 0);
        }

        mouseAccumX -= dx;
        mouseAccumY -= dy;
    }

    if (!bleMouse.isConnected())
    {
        resetCursorOutput();
    }
}

void handleImuOutput()
{
    uint32_t nowUs = micros();
    float dt = (float)(nowUs - previousTimeUs) / 1000000.0f;
    previousTimeUs = nowUs;

    if (dt <= 0.0f || dt > 0.1f)
    {
        dt = 0.01f;
    }

    if (outputLocked())
    {
        resetCursorOutput();
        resetGyroFilter();
        return;
    }

    float gx;
    float gy;
    float gz;

    if (!readCorrectedGyro(gx, gy, gz))
    {
        return;
    }

    emitCursor(gx, gz, dt);
}

void printTuningConfig()
{
    if (!Serial)
    {
        return;
    }

    Serial.print("CFG sx:");
    Serial.print(cursorXSensitivity, 2);
    Serial.print(" sy:");
    Serial.print(cursorYSensitivity, 2);
    Serial.print(" dz:");
    Serial.print(cursorDeadzoneDps, 3);
    Serial.print(" lpf:");
    Serial.print(gyroLpfAlpha, 3);
    Serial.print(" sign_inv:");
    Serial.print(cursorSignsInverted ? 1 : 0);
    Serial.print(" bias_x:");
    Serial.print(gyroBiasX, 6);
    Serial.print(" bias_y:");
    Serial.print(gyroBiasY, 6);
    Serial.print(" bias_z:");
    Serial.print(gyroBiasZ, 6);
    Serial.print(" ble:");
    Serial.println(bleMouse.isConnected() ? 1 : 0);
}

void printCalibrationSample()
{
    if (!Serial || !calibrationStreamEnabled)
    {
        return;
    }

    uint32_t nowMs = millis();

    if (nowMs - lastCalibrationStreamMs < CALIBRATION_STREAM_INTERVAL_MS)
    {
        return;
    }

    lastCalibrationStreamMs = nowMs;

    if (IMU.gyroscopeAvailable())
    {
        float rawGx;
        float rawGy;
        float rawGz;

        if (IMU.readGyroscope(rawGx, rawGy, rawGz))
        {
            latestRawGx = rawGx;
            latestRawGy = rawGy;
            latestRawGz = rawGz;
        }
    }

    Serial.print(nowMs);
    Serial.print(",");
    Serial.print(analogRead(PIN_FLEX_LEFT));
    Serial.print(",");
    Serial.print(analogRead(PIN_FLEX_RIGHT));
    Serial.print(",");
    Serial.print(latestRawGx, 6);
    Serial.print(",");
    Serial.print(latestRawGy, 6);
    Serial.print(",");
    Serial.println(latestRawGz, 6);
}

bool captureGyroBias(uint16_t targetSamples)
{
    float sumX = 0.0f;
    float sumY = 0.0f;
    float sumZ = 0.0f;
    uint16_t count = 0;
    uint32_t startMs = millis();

    while (count < targetSamples && millis() - startMs < 2500)
    {
        if (!IMU.gyroscopeAvailable())
        {
            delay(1);
            continue;
        }

        float gx;
        float gy;
        float gz;

        if (IMU.readGyroscope(gx, gy, gz))
        {
            sumX += gx;
            sumY += gy;
            sumZ += gz;
            count++;
        }
    }

    if (count < 10)
    {
        return false;
    }

    gyroBiasX = sumX / (float)count;
    gyroBiasY = sumY / (float)count;
    gyroBiasZ = sumZ / (float)count;
    resetCursorOutput();
    resetGyroFilter();
    previousTimeUs = micros();
    return true;
}

void acknowledgeCommand(const char *name)
{
    if (!Serial)
    {
        return;
    }

    Serial.print("OK ");
    Serial.print(name);
    Serial.print(" ");
    printTuningConfig();
}

void rejectCommand(const char *reason)
{
    if (!Serial)
    {
        return;
    }

    Serial.print("ERR ");
    Serial.println(reason);
}

void processSerialCommand(char *command)
{
    char *cursor = command;
    while (*cursor == ' ' || *cursor == '\t')
    {
        cursor++;
    }

    if (*cursor == '\0')
    {
        return;
    }

    for (char *p = cursor; *p != '\0'; p++)
    {
        if (*p >= 'a' && *p <= 'z')
        {
            *p = *p - 'a' + 'A';
        }
    }

    if (strncmp(cursor, "SX=", 3) == 0)
    {
        cursorXSensitivity = constrain(atof(cursor + 3), 0.0f, 500.0f);
        acknowledgeCommand("SX");
        return;
    }

    if (strncmp(cursor, "SY=", 3) == 0)
    {
        cursorYSensitivity = constrain(atof(cursor + 3), 0.0f, 500.0f);
        acknowledgeCommand("SY");
        return;
    }

    if (strncmp(cursor, "DZ=", 3) == 0)
    {
        cursorDeadzoneDps = constrain(atof(cursor + 3), 0.0f, 20.0f);
        resetCursorOutput();
        acknowledgeCommand("DZ");
        return;
    }

    if (strncmp(cursor, "LPF=", 4) == 0)
    {
        gyroLpfAlpha = constrain(atof(cursor + 4), 0.01f, 1.0f);
        resetGyroFilter();
        acknowledgeCommand("LPF");
        return;
    }

    if (strncmp(cursor, "DEBUG=", 6) == 0)
    {
        debugOutputEnabled = atoi(cursor + 6) != 0;
        acknowledgeCommand("DEBUG");
        return;
    }

    if (strncmp(cursor, "STREAM=", 7) == 0)
    {
        calibrationStreamEnabled = atoi(cursor + 7) != 0;
        lastCalibrationStreamMs = 0;
        debugOutputEnabled = false;

        if (Serial)
        {
            Serial.println(calibrationStreamEnabled ? "OK STREAM 1" : "OK STREAM 0");
        }

        return;
    }

    if (strcmp(cursor, "BIAS") == 0)
    {
        if (Serial)
        {
            Serial.println("OK BIAS_START keep the board still");
        }

        if (captureGyroBias(120))
        {
            acknowledgeCommand("BIAS");
        }
        else
        {
            rejectCommand("BIAS_FAILED");
        }

        return;
    }

    if (strcmp(cursor, "PRINT") == 0 || strcmp(cursor, "?") == 0)
    {
        printTuningConfig();
        return;
    }

    rejectCommand("UNKNOWN_COMMAND");
}

void handleSerialCommands()
{
    if (!Serial)
    {
        return;
    }

    static char buffer[SERIAL_COMMAND_BUFFER_SIZE];
    static uint8_t index = 0;

    while (Serial.available() > 0)
    {
        char c = (char)Serial.read();

        if (c == '\r')
        {
            continue;
        }

        if (c == '\n')
        {
            buffer[index] = '\0';
            processSerialCommand(buffer);
            index = 0;
            continue;
        }

        if (index < SERIAL_COMMAND_BUFFER_SIZE - 1)
        {
            buffer[index++] = c;
        }
        else
        {
            index = 0;
            rejectCommand("COMMAND_TOO_LONG");
        }
    }
}

void printDebug()
{
    if (!debugOutputEnabled || !Serial)
    {
        return;
    }

    static uint32_t lastPrintMs = 0;
    uint32_t nowMs = millis();

    if (nowMs - lastPrintMs < DEBUG_INTERVAL_MS)
    {
        return;
    }

    lastPrintMs = nowMs;
    Serial.print("mode:");
    Serial.print(modeName(controlMode));
    Serial.print(" L_raw:");
    Serial.print(leftSensor.raw);
    Serial.print(" L_delta:");
    Serial.print(leftSensor.signedDelta);
    Serial.print(" L_slope:");
    Serial.print(leftSensor.slope, 1);
    Serial.print(" L_pressed:");
    Serial.print(leftSensor.pressed ? 1 : 0);
    Serial.print(" R_raw:");
    Serial.print(rightSensor.raw);
    Serial.print(" R_delta:");
    Serial.print(rightSensor.signedDelta);
    Serial.print(" R_slope:");
    Serial.print(rightSensor.slope, 1);
    Serial.print(" R_pressed:");
    Serial.print(rightSensor.pressed ? 1 : 0);
    Serial.print(" gyro:");
    Serial.print(gyroMotionDps, 1);
    Serial.print(" block:");
    Serial.print(clickMotionTooLarge ? 1 : 0);
    Serial.print(" lock:");
    Serial.print(outputLocked() ? 1 : 0);
    Serial.print(" dx:");
    Serial.print(lastMouseDx);
    Serial.print(" dy:");
    Serial.print(lastMouseDy);
    Serial.print(" accx:");
    Serial.print(mouseAccumX, 2);
    Serial.print(" accy:");
    Serial.print(mouseAccumY, 2);
    Serial.print(" sx:");
    Serial.print(cursorXSensitivity, 1);
    Serial.print(" sy:");
    Serial.print(cursorYSensitivity, 1);
    Serial.print(" sign_inv:");
    Serial.print(cursorSignsInverted ? 1 : 0);
    Serial.print(" drag:");
    Serial.print(dragButtonDown ? 1 : 0);
    Serial.print(" ble:");
    Serial.println(bleMouse.isConnected() ? 1 : 0);
}

void printConfigSummary()
{
    if (!debugOutputEnabled || !Serial)
    {
        return;
    }

    Serial.print("CFG cursor_x:");
    Serial.print(cursorXSensitivity, 2);
    Serial.print(" cursor_y:");
    Serial.print(cursorYSensitivity, 2);
    Serial.print(" mouse_x_sign:");
    Serial.print(MOUSE_X_SIGN, 1);
    Serial.print(" mouse_y_sign:");
    Serial.print(MOUSE_Y_SIGN, 1);
    Serial.print(" left_slope:");
    Serial.print(FLEX_PRESS_SLOPE_LEFT, 1);
    Serial.print(" right_slope:");
    Serial.print(FLEX_PRESS_SLOPE_RIGHT, 1);
    Serial.print(" left_delta:");
    Serial.print(FLEX_PRESS_DELTA_LEFT);
    Serial.print(" right_delta:");
    Serial.print(FLEX_PRESS_DELTA_RIGHT);
    Serial.print(" double_ms:");
    Serial.print(LONG_GESTURE_HOLD_MS);
    Serial.print(" drag_ms:");
    Serial.print(DRAG_START_HOLD_MS);
    Serial.print(" sign_invert_ms:");
    Serial.println(AXIS_SWAP_HOLD_MS);
}

void setup()
{
    Serial.begin(115200);
    pinMode(LED_BUILTIN, OUTPUT);

    if (debugOutputEnabled)
    {
        uint32_t serialWaitStartMs = millis();

        while (!Serial && millis() - serialWaitStartMs < DEBUG_SERIAL_WAIT_MS)
        {
            delay(10);
        }

        if (Serial)
        {
            Serial.println();
            Serial.println("Nano 33 BLE Rev2 Test1_FlexSensor Assistive Air Mouse");
        }
    }

    if (!IMU.begin())
    {
        if (Serial)
        {
            Serial.println("ERROR: IMU initialization failed.");
        }

        while (true)
        {
            digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
            delay(200);
        }
    }

    initFlexSensor(leftSensor);
    initFlexSensor(rightSensor);

    bleMouse.setDeviceName("Nano Flex Mouse T1");
    bleMouse.setManufacturerName("Nano33BLE");
    bleMouse.setBatteryLevel(100);
    bleMouse.begin();

    previousTimeUs = micros();

    if (debugOutputEnabled && Serial)
    {
        printConfigSummary();
        Serial.println("A0 short = left click");
        Serial.println("A1 short = right click");
        Serial.println("A0 long = left double click");
        Serial.println("A1 long = drag/drop");
        Serial.println("A0 + A1 hold = invert mouse X/Y directions");
        Serial.println("BLE advertising as: Nano Flex Mouse T1");
    }
}

void loop()
{
    handleSerialCommands();

    if (calibrationStreamEnabled)
    {
        printCalibrationSample();
        digitalWrite(LED_BUILTIN, bleMouse.isConnected() ? HIGH : LOW);
        return;
    }

    updateAllFlexSensors();
    handleGestureState();
    handleImuOutput();
    printCalibrationSample();
    printDebug();

    digitalWrite(LED_BUILTIN, bleMouse.isConnected() ? HIGH : LOW);
}
