#!/usr/bin/env python3
"""One-window setup app for the Nano 33 BLE Rev2 Flex Air Mouse package."""

from __future__ import annotations

import argparse  # bundled for external calibration scripts
import csv  # bundled for external calibration scripts
import json  # bundled for external calibration scripts
import math  # bundled for external calibration scripts
import os
import queue  # bundled for external calibration scripts
import runpy
import statistics  # bundled for external calibration scripts
import subprocess
import sys
import threading
import tkinter as tk
import time  # bundled for external calibration scripts
from dataclasses import dataclass  # bundled for external calibration scripts
from datetime import datetime, timezone  # bundled for external calibration scripts
from pathlib import Path
from tkinter import messagebox

try:
    import serial  # noqa: F401
    from serial.tools import list_ports  # noqa: F401
except Exception:
    pass


APP_TITLE = "Nano 33 BLE Rev2 Flex Air Mouse Setup"
DEFAULT_PORT = "AUTO"
DEFAULT_BAUD = "115200"


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT = app_root()


def script_command(script: Path, *args: str) -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--run-script", str(script), *args]
    return [sys.executable, str(script), *args]


def run_external_script(argv: list[str]) -> int:
    if len(argv) < 3:
        print("Missing script path", file=sys.stderr)
        return 2
    script = Path(argv[2]).resolve()
    if not script.exists():
        print(f"Script not found: {script}", file=sys.stderr)
        return 2
    sys.path.insert(0, str(script.parent))
    sys.argv = [str(script), *argv[3:]]
    runpy.run_path(str(script), run_name="__main__")
    return 0


class SetupApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.processes: list[subprocess.Popen] = []

        self.root.title(APP_TITLE)
        self.root.geometry("980x720")
        self.root.configure(bg="#f5f7fb")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        header = tk.Frame(root, bg="#0f172a")
        header.pack(fill="x")
        tk.Label(
            header,
            text="Nano 33 BLE Rev2 Flex Air Mouse",
            bg="#0f172a",
            fg="white",
            font=("Segoe UI", 22, "bold"),
            padx=20,
            pady=16,
        ).pack(side="left")
        tk.Label(
            header,
            text="setup app",
            bg="#0f172a",
            fg="#cbd5e1",
            font=("Segoe UI", 12),
            padx=20,
        ).pack(side="right")

        main = tk.Frame(root, bg="#f5f7fb")
        main.pack(fill="both", expand=True, padx=18, pady=18)

        settings = tk.Frame(main, bg="#ffffff", bd=1, relief="solid")
        settings.pack(fill="x", pady=(0, 12))

        tk.Label(
            settings,
            text="연결 설정",
            bg="#ffffff",
            fg="#0f172a",
            font=("Segoe UI", 14, "bold"),
            padx=16,
            pady=12,
        ).grid(row=0, column=0, sticky="w")

        tk.Label(settings, text="COM Port", bg="#ffffff", font=("Segoe UI", 11)).grid(row=1, column=0, sticky="w", padx=16)
        self.port_var = tk.StringVar(value=DEFAULT_PORT)
        tk.Entry(settings, textvariable=self.port_var, width=18, font=("Consolas", 12)).grid(row=1, column=1, sticky="w", padx=8)

        tk.Label(settings, text="Baud", bg="#ffffff", font=("Segoe UI", 11)).grid(row=1, column=2, sticky="w", padx=(28, 4))
        self.baud_var = tk.StringVar(value=DEFAULT_BAUD)
        tk.Entry(settings, textvariable=self.baud_var, width=10, font=("Consolas", 12)).grid(row=1, column=3, sticky="w", padx=8)

        tk.Button(settings, text="README 열기", command=self.open_readme).grid(row=1, column=4, sticky="e", padx=12)
        tk.Button(settings, text="Bluetooth 설정", command=self.open_bluetooth).grid(row=1, column=5, sticky="e", padx=(0, 16))
        settings.grid_columnconfigure(6, weight=1)

        steps = tk.Frame(main, bg="#f5f7fb")
        steps.pack(fill="both", expand=True)

        self.add_step(
            steps,
            0,
            "1",
            "Python 패키지 설치",
            "처음 한 번만 실행합니다. pyserial을 설치합니다.",
            "설치 실행",
            self.install_requirements,
        )
        self.add_step(
            steps,
            1,
            "2",
            "Gyro RawLogger 업로드",
            "Arduino IDE에서 Gyro_RawLogger.ino를 열고 Nano 33 BLE Rev2에 업로드합니다.",
            "Arduino 파일 열기",
            lambda: self.open_file(ROOT / "Gyro_Calibration" / "Gyro_RawLogger" / "Gyro_RawLogger.ino"),
        )
        self.add_step(
            steps,
            2,
            "3",
            "Gyro calibration 실행",
            "GUI 안내에 따라 정지 수집과 X/Y/Z 360도 회전을 진행합니다. 끝나면 Test1 설정에 자동 반영됩니다.",
            "Gyro GUI 실행",
            self.run_gyro_gui,
        )
        self.add_step(
            steps,
            3,
            "4",
            "Test1_FlexSensor 임시 업로드",
            "Flex calibration GUI가 Arduino Serial stream을 읽을 수 있도록 runtime을 한 번 업로드합니다.",
            "Arduino 파일 열기",
            lambda: self.open_file(ROOT / "Test1_FlexSensor" / "Test1_FlexSensor.ino"),
        )
        self.add_step(
            steps,
            4,
            "5",
            "Flex / Click / IMU calibration",
            "A0/A1 threshold, 더블클릭, 드래그, IMU 감도를 GUI에서 조절합니다.",
            "Flex GUI 실행",
            self.run_flex_gui,
        )
        self.add_step(
            steps,
            5,
            "6",
            "최종 업로드",
            "Flex GUI 저장 후 Test1_FlexSensor.ino를 다시 업로드합니다. 이후 Bluetooth에서 Nano Flex Mouse T1을 연결합니다.",
            "최종 Arduino 열기",
            lambda: self.open_file(ROOT / "Test1_FlexSensor" / "Test1_FlexSensor.ino"),
        )

        bottom = tk.Frame(main, bg="#ffffff", bd=1, relief="solid")
        bottom.pack(fill="both", pady=(12, 0))
        tk.Label(
            bottom,
            text="로그",
            bg="#ffffff",
            fg="#0f172a",
            font=("Segoe UI", 12, "bold"),
            padx=12,
            pady=8,
        ).pack(anchor="w")
        self.log_text = tk.Text(
            bottom,
            height=9,
            bg="#0f172a",
            fg="#cbd5e1",
            insertbackground="white",
            font=("Consolas", 10),
        )
        self.log_text.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.log(f"Package folder: {ROOT}")

    def add_step(
        self,
        parent: tk.Frame,
        row: int,
        number: str,
        title: str,
        description: str,
        button_text: str,
        command,
    ) -> None:
        frame = tk.Frame(parent, bg="#ffffff", bd=1, relief="solid")
        frame.grid(row=row, column=0, sticky="ew", pady=5)
        parent.grid_columnconfigure(0, weight=1)

        tk.Label(
            frame,
            text=number,
            bg="#2563eb",
            fg="white",
            width=4,
            font=("Segoe UI", 16, "bold"),
            pady=12,
        ).pack(side="left", fill="y")

        text_frame = tk.Frame(frame, bg="#ffffff")
        text_frame.pack(side="left", fill="both", expand=True, padx=14, pady=10)
        tk.Label(
            text_frame,
            text=title,
            bg="#ffffff",
            fg="#0f172a",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            text_frame,
            text=description,
            bg="#ffffff",
            fg="#475569",
            font=("Segoe UI", 10),
            anchor="w",
            justify="left",
            wraplength=620,
        ).pack(fill="x", pady=(3, 0))

        tk.Button(
            frame,
            text=button_text,
            command=command,
            width=18,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="right", padx=14, pady=12)

    def log(self, text: str) -> None:
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")

    def port(self) -> str:
        return self.port_var.get().strip() or "AUTO"

    def baud(self) -> str:
        return self.baud_var.get().strip() or DEFAULT_BAUD

    def open_file(self, path: Path) -> None:
        if not path.exists():
            messagebox.showerror("파일 없음", str(path))
            return
        os.startfile(path)
        self.log(f"Opened: {path}")

    def open_readme(self) -> None:
        self.open_file(ROOT / "README.md")

    def open_bluetooth(self) -> None:
        os.startfile("ms-settings:bluetooth")
        self.log("Opened Windows Bluetooth settings")

    def install_requirements(self) -> None:
        if getattr(sys, "frozen", False):
            self.log("EXE mode: Python requirements are bundled in the setup app.")
            return
        req = ROOT / "Gyro_Calibration" / "requirements.txt"
        self.run_capture(
            [sys.executable, "-m", "pip", "install", "-r", str(req)],
            "Installing Python requirements",
        )

    def run_gyro_gui(self) -> None:
        script = ROOT / "Gyro_Calibration" / "gyro_calibration_gui.py"
        self.run_process(
            script_command(script, "--port", self.port(), "--baud", self.baud()),
            "Gyro calibration GUI started",
        )

    def run_flex_gui(self) -> None:
        script = ROOT / "Test1_FlexSensor_Calibration" / "manual_calibrate_test1_flex_gui.py"
        self.run_process(
            script_command(script, "--port", self.port(), "--baud", self.baud()),
            "Flex calibration GUI started",
        )

    def run_process(self, command: list[str], message: str) -> None:
        try:
            process = subprocess.Popen(command, cwd=ROOT)
        except Exception as exc:
            messagebox.showerror("실행 실패", str(exc))
            self.log(f"ERROR: {exc}")
            return
        self.processes.append(process)
        self.log(message)
        self.log(" ".join(command))

    def run_capture(self, command: list[str], message: str) -> None:
        self.log(message)
        self.log(" ".join(command))

        def worker() -> None:
            try:
                process = subprocess.Popen(
                    command,
                    cwd=ROOT,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                self.processes.append(process)
                assert process.stdout is not None
                for line in process.stdout:
                    self.root.after(0, self.log, line.rstrip())
                code = process.wait()
                self.root.after(0, self.log, f"Process finished with code {code}")
            except Exception as exc:
                self.root.after(0, self.log, f"ERROR: {exc}")

        threading.Thread(target=worker, daemon=True).start()

    def on_close(self) -> None:
        alive = [p for p in self.processes if p.poll() is None]
        if alive:
            ok = messagebox.askyesno(
                "종료 확인",
                "실행 중인 calibration 창이 있을 수 있습니다. 런처를 종료할까요?",
            )
            if not ok:
                return
        self.root.destroy()


def main() -> int:
    if len(sys.argv) > 1 and sys.argv[1] == "--run-script":
        return run_external_script(sys.argv)
    root = tk.Tk()
    SetupApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
