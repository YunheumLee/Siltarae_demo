# Test1 FlexSensor Calibration

`Test1_FlexSensor`의 클릭 threshold와 IMU 사용감을 조절하는 GUI입니다.

## 실행 전

먼저 아래 스케치를 Arduino에 업로드합니다.

```text
../Test1_FlexSensor/Test1_FlexSensor.ino
```

그 다음 GUI를 실행합니다.

```powershell
cd "../"
python Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py --port COM3
```

## 조작 방법

- Enter: 현재 단계 시작 또는 저장 후 다음 단계
- ← / →: 현재 값을 낮추거나 올림
- ESC: 저장 후 종료

## Calibration 단계

- 기준값 수집: 손가락을 펴고 10초 정지
- A0 좌클릭 threshold
- A1 우클릭 threshold
- A0 길게: 더블클릭 시간
- A1 길게: 드래그 시작 시간
- A0+A1 길게: 마우스 X/Y 방향 부호 전환 시간
- 수평 IMU 감도
- 수직 IMU 감도
- deadzone
- 최종 저장

## 저장되는 파일

```text
Test1_FlexSensor_Calibration/test1_flex_calibration.json
Test1_FlexSensor/flex_config.h
```

## Gyro 값 유지

이 GUI는 gyro bias/scale을 새로 계산하지 않습니다.
정밀 gyro 값은 `Gyro_Calibration/fit_and_apply_gyro_calibration.py`가 반영합니다.

권장 순서:

```text
1. Gyro_Calibration 수행
2. fit_and_apply_gyro_calibration.py 실행
3. Test1_FlexSensor_Calibration 수행
4. Test1_FlexSensor.ino 최종 업로드
```
