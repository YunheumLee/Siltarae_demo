from __future__ import annotations

import argparse
import csv
import json
import math
import queue
import statistics as stats
import threading
import time
import tkinter as tk
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from tkinter import messagebox

try:
    import serial
    from serial.tools import list_ports
except ImportError as exc:
    raise SystemExit("Install pyserial first: pip install pyserial") from exc


SERIAL_PORT = "AUTO"
BAUD_RATE = 115200

ROOT = Path(__file__).resolve().parents[1]
CALIB_DIR = ROOT / "Test1_FlexSensor_Calibration"
SESSIONS_DIR = CALIB_DIR / "calibration_sessions"
LATEST_JSON = CALIB_DIR / "test1_flex_calibration.json"
HEADER_OUT = ROOT / "Test1_FlexSensor" / "flex_config.h"


@dataclass
class Sample:
    label: str
    t_ms: int
    a0: int
    a1: int
    gx: float
    gy: float
    gz: float


DEFAULT_CONFIG = {
    "schema_version": 1,
    "generated_at": "default",
    "board": "Arduino Nano 33 BLE Rev2",
    "calibration_sketch": "Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py",
    "target_sketch": "Test1_FlexSensor/Test1_FlexSensor.ino",
    "runtime_sketch": "Test1_FlexSensor/Test1_FlexSensor.ino",
    "calibration_gui": "Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py",
    "serial": {"port": "AUTO", "baud": BAUD_RATE},
    "flex": {
        "left": {
            "baseline_adc": 0.0,
            "active_sign": 1,
            "press_delta": 12,
            "release_delta": 6,
            "press_slope_adc_per_s": 40.0,
        },
        "right": {
            "baseline_adc": 0.0,
            "active_sign": 1,
            "press_delta": 16,
            "release_delta": 8,
            "press_slope_adc_per_s": 80.0,
        },
        "opposite_delta_max": 13,
    },
    "imu": {
        "gyro_bias_dps": {"x": -0.307244967, "y": -0.028544303, "z": -0.068544667},
        "gyro_scale": {"x": -0.9751877, "y": -1.011479802, "z": 0.99409448},
        "click_allowed_motion_dps": 35.0,
        "cursor_deadzone_dps": 0.5,
        "cursor_x_sensitivity": 70.0,
        "cursor_y_sensitivity": 70.0,
        "mouse_x_sign": -1.0,
        "mouse_y_sign": 1.0,
        "gyro_lpf_alpha": 0.35,
    },
    "gesture": {
        "click_min_hold_ms": 50,
        "click_max_hold_ms": 1100,
        "click_freeze_ms": 240,
        "click_refractory_ms": 280,
        "dual_press_window_ms": 300,
        "long_gesture_hold_ms": 500,
        "drag_start_hold_ms": 500,
        "axis_swap_hold_ms": 500,
        "double_click_gap_ms": 80,
    },
}


PAGES = [
    {
        "title": "1. 기준값 수집",
        "kind": "collect",
        "phase": "idle",
        "duration": 10.0,
        "stream": True,
        "guide": "손가락을 편하게 펴고 보드를 움직이지 않습니다. Enter를 누르면 10초 동안 baseline을 수집합니다.",
    },
    {
        "title": "2. A0 좌클릭 threshold",
        "kind": "adjust",
        "path": "flex.left.press_slope_adc_per_s",
        "label": "A0 좌클릭 slope threshold",
        "low": 0,
        "high": 2000,
        "step": 5,
        "digits": 0,
        "stream": True,
        "guide": "A0를 실제 좌클릭처럼 움직이면서 좌클릭 ON이 원하는 순간에만 켜지도록 ←/→로 threshold를 직접 맞춥니다. 너무 안 켜지면 낮추고, 너무 쉽게 켜지면 올립니다.",
    },
    {
        "title": "3. A1 우클릭 threshold",
        "kind": "adjust",
        "path": "flex.right.press_slope_adc_per_s",
        "label": "A1 우클릭 slope threshold",
        "low": 0,
        "high": 2000,
        "step": 5,
        "digits": 0,
        "stream": True,
        "guide": "A1을 실제 우클릭처럼 움직이면서 우클릭 ON이 원하는 순간에만 켜지도록 ←/→로 threshold를 직접 맞춥니다. 너무 안 켜지면 낮추고, 너무 쉽게 켜지면 올립니다.",
    },
    {
        "title": "4. 더블클릭 시간",
        "kind": "adjust",
        "path": "gesture.long_gesture_hold_ms",
        "label": "A0 길게: 더블클릭 시간",
        "low": 0,
        "high": 800,
        "step": 5,
        "digits": 0,
        "stream": True,
        "guide": "A0를 길게 누르면서 READY가 편한 시점에 켜지는지 봅니다. ←/→로 조절하고 Enter로 다음 단계.",
    },
    {
        "title": "5. 드래그 시간",
        "kind": "adjust",
        "path": "gesture.drag_start_hold_ms",
        "label": "A1 길게: 드래그 시작 시간",
        "low": 0,
        "high": 800,
        "step": 5,
        "digits": 0,
        "stream": True,
        "guide": "A1을 길게 누르면서 READY가 편한 시점에 켜지는지 봅니다. ←/→로 조절하고 Enter로 다음 단계.",
    },
    {
        "title": "6. 방향 부호 전환 시간",
        "kind": "adjust",
        "path": "gesture.axis_swap_hold_ms",
        "label": "A0+A1 길게: 마우스 X/Y 방향 부호 전환 시간",
        "low": 0,
        "high": 800,
        "step": 5,
        "digits": 0,
        "stream": True,
        "guide": "A0와 A1을 같이 구부렸을 때 부호 전환 READY가 편한 시점에 켜지도록 ←/→로 조절합니다. 기본값은 500ms입니다.",
    },
    {
        "title": "7. 수평 감도",
        "kind": "imu",
        "path": "imu.cursor_x_sensitivity",
        "command": "SX",
        "label": "SX 수평 감도",
        "low": 0,
        "high": 500,
        "step": 5,
        "digits": 0,
        "stream": False,
        "guide": "실제 Windows 커서를 보면서 좌우 이동량을 맞춥니다. ←/→로 조절하고 Enter로 다음 단계.",
    },
    {
        "title": "8. 수직 감도",
        "kind": "imu",
        "path": "imu.cursor_y_sensitivity",
        "command": "SY",
        "label": "SY 수직 감도",
        "low": 0,
        "high": 500,
        "step": 5,
        "digits": 0,
        "stream": False,
        "guide": "실제 Windows 커서를 보면서 위아래 이동량을 맞춥니다. ←/→로 조절하고 Enter로 다음 단계.",
    },
    {
        "title": "9. 떨림 제거",
        "kind": "imu",
        "path": "imu.cursor_deadzone_dps",
        "command": "DZ",
        "label": "DZ deadzone",
        "low": 0.0,
        "high": 10.0,
        "step": 0.1,
        "digits": 1,
        "stream": False,
        "guide": "가만히 있을 때 커서가 떨리면 올립니다. 너무 높이면 작은 움직임이 안 먹습니다.",
    },
    {
        "title": "10. 최종 저장",
        "kind": "save",
        "stream": False,
        "guide": "Enter를 누르면 JSON과 Test1_FlexSensor/flex_config.h를 저장합니다. Gyro bias/scale은 Gyro_Calibration에서 만든 정밀 값을 유지합니다.",
    },
]


def deep_copy_default() -> dict:
    return json.loads(json.dumps(DEFAULT_CONFIG))


def merge_defaults(config: dict, defaults: dict) -> dict:
    for key, value in defaults.items():
        if key not in config:
            config[key] = json.loads(json.dumps(value))
        elif isinstance(value, dict) and isinstance(config[key], dict):
            merge_defaults(config[key], value)
    return config


def choose_serial_port(requested: str) -> str:
    if requested and requested.upper() != "AUTO":
        return requested

    ports = list(list_ports.comports())
    keywords = ("ARDUINO", "NANO", "MBED", "USB SERIAL", "USB")
    for port in ports:
        text = " ".join([port.device or "", port.description or "", port.manufacturer or ""]).upper()
        if any(keyword in text for keyword in keywords):
            return port.device

    if ports:
        return ports[0].device
    return "COM3"


def load_config() -> dict:
    config = deep_copy_default()
    if LATEST_JSON.exists():
        try:
            saved = json.loads(LATEST_JSON.read_text(encoding="utf-8-sig"))
            config = merge_defaults(saved, config)
        except Exception:
            pass
    normalize_step_values(config)
    return config


def parse_sample(line: str, label: str) -> Sample | None:
    line = line.strip()
    if not line or line.startswith("OK") or line.startswith("ERR") or line.startswith("CFG"):
        return None
    parts = line.split(",")
    if len(parts) != 6:
        return None
    try:
        return Sample(
            label=label,
            t_ms=int(parts[0]),
            a0=int(parts[1]),
            a1=int(parts[2]),
            gx=float(parts[3]),
            gy=float(parts[4]),
            gz=float(parts[5]),
        )
    except ValueError:
        return None


def percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    sorted_values = sorted(values)
    index = round((len(sorted_values) - 1) * q)
    index = max(0, min(len(sorted_values) - 1, index))
    return float(sorted_values[index])


def median(values: list[float]) -> float:
    return float(stats.median(values)) if values else 0.0


def snap_to_step(value: float, step: int = 5, upward: bool = False) -> int:
    if step <= 0:
        return int(round(value))
    if upward:
        return int(math.ceil(float(value) / float(step)) * step)
    return int(round(float(value) / float(step)) * step)


def normalize_step_values(config: dict) -> None:
    for path in [
        "flex.left.press_slope_adc_per_s",
        "flex.right.press_slope_adc_per_s",
        "gesture.long_gesture_hold_ms",
        "gesture.drag_start_hold_ms",
        "gesture.axis_swap_hold_ms",
        "imu.cursor_x_sensitivity",
        "imu.cursor_y_sensitivity",
    ]:
        value = get_nested(config, path)
        set_nested(config, path, max(0, snap_to_step(float(value), 5)))


def signed_features(samples: list[Sample], channel: str, baseline: float, sign: int) -> tuple[list[float], list[float]]:
    deltas = [sign * (float(getattr(sample, channel)) - baseline) for sample in samples]
    slopes: list[float] = []
    start = 0

    for index, sample in enumerate(samples):
        while start < index and sample.t_ms - samples[start].t_ms > 130:
            start += 1
        if index - start >= 3:
            dt = sample.t_ms - samples[start].t_ms
            if dt > 0:
                raw_delta = float(getattr(sample, channel) - getattr(samples[start], channel))
                slopes.append(sign * raw_delta * 1000.0 / dt)

    return deltas, slopes


def estimate_imu_bias(idle: list[Sample]) -> dict:
    return {
        "x": round(median([sample.gx for sample in idle]), 9),
        "y": round(median([sample.gy for sample in idle]), 9),
        "z": round(median([sample.gz for sample in idle]), 9),
    }


def update_idle_based_flex_thresholds(config: dict, idle: list[Sample]) -> None:
    for side, channel, min_press, min_release in [
        ("left", "a0", 12, 6),
        ("right", "a1", 16, 8),
    ]:
        sensor = config["flex"][side]
        baseline = float(sensor["baseline_adc"])
        sign = int(sensor["active_sign"])
        idle_deltas, idle_slopes = signed_features(idle, channel, baseline, sign)
        idle_abs_delta_p99 = percentile([abs(value) for value in idle_deltas], 0.99)
        idle_abs_slope_p99 = percentile([abs(value) for value in idle_slopes], 0.99)

        sensor["press_delta"] = int(round(max(float(min_press), idle_abs_delta_p99 * 4.0)))
        sensor["release_delta"] = int(round(max(float(min_release), idle_abs_delta_p99 * 2.0)))
        current_slope = float(sensor["press_slope_adc_per_s"])
        sensor["press_slope_adc_per_s"] = snap_to_step(max(0.0, current_slope, idle_abs_slope_p99 * 5.0), 5, upward=True)


def get_nested(config: dict, path: str):
    cur = config
    for key in path.split("."):
        cur = cur[key]
    return cur


def set_nested(config: dict, path: str, value) -> None:
    cur = config
    parts = path.split(".")
    for key in parts[:-1]:
        cur = cur[key]
    cur[parts[-1]] = value


def float_literal(value: float, digits: int = 6) -> str:
    return f"{float(value):.{digits}f}f"


def render_header(config: dict) -> str:
    left = config["flex"]["left"]
    right = config["flex"]["right"]
    imu = config["imu"]
    gesture = config["gesture"]
    return f"""#pragma once

#include <Arduino.h>

// Auto-generated by Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py
// Source JSON: Test1_FlexSensor_Calibration/test1_flex_calibration.json

constexpr float INITIAL_GYRO_BIAS_X = {float_literal(imu["gyro_bias_dps"]["x"], 9)};
constexpr float INITIAL_GYRO_BIAS_Y = {float_literal(imu["gyro_bias_dps"]["y"], 9)};
constexpr float INITIAL_GYRO_BIAS_Z = {float_literal(imu["gyro_bias_dps"]["z"], 9)};
constexpr float GYRO_SCALE_X = {float_literal(imu["gyro_scale"]["x"], 9)};
constexpr float GYRO_SCALE_Y = {float_literal(imu["gyro_scale"]["y"], 9)};
constexpr float GYRO_SCALE_Z = {float_literal(imu["gyro_scale"]["z"], 9)};
constexpr float CURSOR_DEADZONE_DPS = {float_literal(imu["cursor_deadzone_dps"], 4)};
constexpr float CURSOR_X_SENSITIVITY = {float_literal(imu["cursor_x_sensitivity"], 4)};
constexpr float CURSOR_Y_SENSITIVITY = {float_literal(imu["cursor_y_sensitivity"], 4)};
constexpr float MOUSE_X_SIGN = {float_literal(imu["mouse_x_sign"], 1)};
constexpr float MOUSE_Y_SIGN = {float_literal(imu["mouse_y_sign"], 1)};
constexpr float GYRO_LPF_ALPHA = {float_literal(imu["gyro_lpf_alpha"], 4)};
constexpr float CLICK_ALLOWED_MOTION_DPS = {float_literal(imu["click_allowed_motion_dps"], 4)};

constexpr int FLEX_ACTIVE_SIGN_LEFT = {int(left["active_sign"])};
constexpr int FLEX_ACTIVE_SIGN_RIGHT = {int(right["active_sign"])};
constexpr uint32_t FLEX_SAMPLE_INTERVAL_MS = 10;
constexpr uint32_t FLEX_SLOPE_WINDOW_MS = 120;
constexpr uint8_t FLEX_SLOPE_BUFFER_SIZE = 24;
constexpr uint32_t FLEX_BASELINE_CAPTURE_MS = 1500;
constexpr float FLEX_BASELINE_ALPHA = 0.0015f;
constexpr float FLEX_SLOPE_ALPHA = 0.35f;

constexpr int FLEX_PRESS_DELTA_LEFT = {int(left["press_delta"])};
constexpr int FLEX_RELEASE_DELTA_LEFT = {int(left["release_delta"])};
constexpr int FLEX_PRESS_DELTA_RIGHT = {int(right["press_delta"])};
constexpr int FLEX_RELEASE_DELTA_RIGHT = {int(right["release_delta"])};
constexpr float FLEX_PRESS_SLOPE_LEFT = {float_literal(left["press_slope_adc_per_s"], 3)};
constexpr float FLEX_PRESS_SLOPE_RIGHT = {float_literal(right["press_slope_adc_per_s"], 3)};
constexpr uint32_t FLEX_RELEASE_CONFIRM_MS = 90;
constexpr int FLEX_OPPOSITE_DELTA_MAX = {int(config["flex"]["opposite_delta_max"])};

constexpr uint32_t CLICK_MIN_HOLD_MS = {int(gesture["click_min_hold_ms"])};
constexpr uint32_t CLICK_MAX_HOLD_MS = {int(gesture["click_max_hold_ms"])};
constexpr uint32_t CLICK_FREEZE_MS = {int(gesture["click_freeze_ms"])};
constexpr uint32_t CLICK_REFRACTORY_MS = {int(gesture["click_refractory_ms"])};
constexpr uint32_t DUAL_PRESS_WINDOW_MS = {int(gesture["dual_press_window_ms"])};
constexpr uint32_t LONG_GESTURE_HOLD_MS = {int(gesture["long_gesture_hold_ms"])};
constexpr uint32_t DRAG_START_HOLD_MS = {int(gesture["drag_start_hold_ms"])};
constexpr uint32_t AXIS_SWAP_HOLD_MS = {int(gesture["axis_swap_hold_ms"])};
constexpr uint32_t DOUBLE_CLICK_GAP_MS = {int(gesture["double_click_gap_ms"])};
"""


def write_samples_csv(path: Path, samples: list[Sample]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=["label", "t_ms", "a0", "a1", "gx", "gy", "gz"])
        writer.writeheader()
        for sample in samples:
            writer.writerow(sample.__dict__)


def write_config(config: dict, port: str, baud: int) -> None:
    config["generated_at"] = datetime.now().isoformat(timespec="seconds")
    config["board"] = "Arduino Nano 33 BLE Rev2"
    config["calibration_sketch"] = "Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py"
    config["target_sketch"] = "Test1_FlexSensor/Test1_FlexSensor.ino"
    config["runtime_sketch"] = "Test1_FlexSensor/Test1_FlexSensor.ino"
    config["calibration_gui"] = "Test1_FlexSensor_Calibration/manual_calibrate_test1_flex_gui.py"
    config["serial"] = {"port": port, "baud": baud}
    CALIB_DIR.mkdir(parents=True, exist_ok=True)
    LATEST_JSON.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    HEADER_OUT.write_text(render_header(config), encoding="utf-8")


class SerialWorker(threading.Thread):
    def __init__(self, port: str, baud: int, out_queue: queue.Queue):
        super().__init__(daemon=True)
        self.port = port
        self.baud = baud
        self.out_queue = out_queue
        self.tx_queue: queue.Queue[str] = queue.Queue()
        self.stop_event = threading.Event()
        self.current_label = "live"

    def send(self, command: str) -> None:
        self.tx_queue.put(command.strip() + "\n")

    def set_label(self, label: str) -> None:
        self.current_label = label

    def run(self) -> None:
        try:
            with serial.Serial(self.port, self.baud, timeout=0.05, write_timeout=0.2) as ser:
                time.sleep(1.2)
                ser.reset_input_buffer()
                self.out_queue.put(("status", f"{self.port} 연결됨"))

                while not self.stop_event.is_set():
                    try:
                        command = self.tx_queue.get_nowait()
                    except queue.Empty:
                        command = ""

                    if command:
                        ser.write(command.encode("utf-8"))
                        ser.flush()

                    line = ser.readline().decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue

                    sample = parse_sample(line, self.current_label)
                    if sample is not None:
                        self.out_queue.put(sample)
                    else:
                        self.out_queue.put(("serial", line))
        except Exception as exc:
            self.out_queue.put(("error", str(exc)))

    def stop(self) -> None:
        self.stop_event.set()
        self.send("STREAM=0")


class Test1FlexSensorCalibrationGui:
    def __init__(self, root: tk.Tk, port: str, baud: int, start_stage: str):
        self.root = root
        self.port = port
        self.baud = baud
        self.start_stage = start_stage
        self.config = load_config()
        write_config(self.config, port, baud)
        self.samples: list[Sample] = []
        self.phase_samples: dict[str, list[Sample]] = {}
        self.live_samples: list[Sample] = []
        self.rx_queue: queue.Queue = queue.Queue()
        self.worker = SerialWorker(port, baud, self.rx_queue)
        self.page_index = self.page_for_stage(start_stage)
        self.collection_label: str | None = None
        self.collection_end_time = 0.0
        self.status = "연결 대기"
        self.last_reply = ""
        self.error = ""
        self.stream_enabled: bool | None = None
        self.prev_sample: Sample | None = None
        self.latest_sample: Sample | None = None
        self.left_slope = 0.0
        self.right_slope = 0.0
        self.left_hold_on = False
        self.right_hold_on = False
        self.left_hold_started_ms = 0
        self.right_hold_started_ms = 0
        self.bias_pending = False

        self.root.title("Test1 FlexSensor Calibration")
        self.root.geometry("1160x760")
        self.root.configure(bg="#f5f7fb")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.bind("<Left>", lambda _event: self.adjust_current(-1))
        self.root.bind("<Right>", lambda _event: self.adjust_current(1))
        self.root.bind("<Return>", lambda _event: self.enter_current_page())
        self.root.bind("<Escape>", lambda _event: self.save_and_close())

        self.build_ui()
        self.apply_stream_for_page()
        self.worker.start()
        self.root.after(60, self.update_loop)

    def page_for_stage(self, stage: str) -> int:
        if stage == "imu":
            for index, page in enumerate(PAGES):
                if page["kind"] == "imu":
                    return index
        return 0

    def current_page(self) -> dict:
        return PAGES[self.page_index]

    def build_ui(self) -> None:
        header = tk.Frame(self.root, bg="#0f172a")
        header.pack(fill="x")
        self.title_label = tk.Label(
            header,
            text="",
            bg="#0f172a",
            fg="white",
            font=("Segoe UI", 18, "bold"),
            padx=18,
            pady=14,
        )
        self.title_label.pack(side="left")
        self.step_label = tk.Label(
            header,
            text="",
            bg="#0f172a",
            fg="#cbd5e1",
            font=("Segoe UI", 11),
            padx=18,
        )
        self.step_label.pack(side="right")

        body = tk.Frame(self.root, bg="#f5f7fb")
        body.pack(fill="both", expand=True, padx=16, pady=16)

        left = tk.Frame(body, bg="#ffffff", bd=1, relief="solid", width=420)
        left.pack(side="left", fill="y", padx=(0, 12))
        left.pack_propagate(False)

        self.guide_label = tk.Label(
            left,
            text="",
            bg="#ffffff",
            fg="#334155",
            justify="left",
            anchor="nw",
            wraplength=360,
            font=("Segoe UI", 12),
            padx=18,
            pady=18,
        )
        self.guide_label.pack(fill="x")

        self.value_label = tk.Label(
            left,
            text="",
            bg="#ffffff",
            fg="#0f172a",
            font=("Segoe UI", 24, "bold"),
            pady=18,
        )
        self.value_label.pack(fill="x", padx=18)

        buttons = tk.Frame(left, bg="#ffffff")
        buttons.pack(fill="x", padx=18, pady=8)
        self.left_button = tk.Button(buttons, text="← 낮추기", command=lambda: self.adjust_current(-1))
        self.left_button.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.enter_button = tk.Button(buttons, text="Enter", command=self.enter_current_page)
        self.enter_button.pack(side="left", fill="x", expand=True, padx=4)
        self.right_button = tk.Button(buttons, text="높이기 →", command=lambda: self.adjust_current(1))
        self.right_button.pack(side="left", fill="x", expand=True, padx=(4, 0))

        nav = tk.Frame(left, bg="#ffffff")
        nav.pack(side="bottom", fill="x", padx=18, pady=18)
        tk.Button(nav, text="이전", command=self.previous_page).pack(side="left", fill="x", expand=True, padx=(0, 4))
        tk.Button(nav, text="현재값 전송", command=self.send_runtime_values).pack(side="left", fill="x", expand=True, padx=4)
        tk.Button(nav, text="저장 종료", command=self.save_and_close).pack(side="left", fill="x", expand=True, padx=(4, 0))

        right = tk.Frame(body, bg="#ffffff", bd=1, relief="solid")
        right.pack(side="left", fill="both", expand=True)
        self.canvas = tk.Canvas(right, bg="#f8fafc", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=14, pady=14)
        self.metrics = tk.Label(
            right,
            text="",
            bg="#ffffff",
            fg="#0f172a",
            justify="left",
            anchor="nw",
            font=("Consolas", 10),
            padx=14,
            pady=12,
        )
        self.metrics.pack(fill="x")
        self.render_page()

    def render_page(self) -> None:
        page = self.current_page()
        self.title_label.config(text=page["title"])
        self.step_label.config(text=f"{self.page_index + 1} / {len(PAGES)}")
        self.guide_label.config(text=page["guide"])

        kind = page["kind"]
        self.left_button.config(state="disabled")
        self.right_button.config(state="disabled")

        if kind == "collect":
            label = page["phase"]
            if self.collection_label == label:
                remaining = max(0, math.ceil(self.collection_end_time - time.monotonic()))
                self.value_label.config(text=f"{remaining}초 남음")
            else:
                self.value_label.config(text=f"{int(page['duration'])}초")
            self.enter_button.config(text="Enter 수집 시작")
        elif kind in {"adjust", "imu"}:
            value = get_nested(self.config, page["path"])
            digits = int(page["digits"])
            number = f"{float(value):.{digits}f}" if digits > 0 else f"{int(round(float(value)))}"
            self.value_label.config(text=f"{page['label']}\n{number}")
            self.enter_button.config(text="Enter 저장 후 다음")
            self.left_button.config(state="normal")
            self.right_button.config(state="normal")
        else:
            self.value_label.config(text="최종 저장")
            self.enter_button.config(text="Enter 저장")

    def apply_stream_for_page(self) -> None:
        should_stream = bool(self.current_page().get("stream", False))
        if should_stream != self.stream_enabled:
            self.stream_enabled = should_stream
            self.worker.send("STREAM=1" if should_stream else "STREAM=0")

    def next_page(self) -> None:
        self.page_index = min(len(PAGES) - 1, self.page_index + 1)
        self.apply_stream_for_page()
        if self.current_page()["kind"] == "imu":
            self.send_runtime_values()
        self.render_page()

    def previous_page(self) -> None:
        self.page_index = max(0, self.page_index - 1)
        self.apply_stream_for_page()
        self.render_page()

    def enter_current_page(self) -> None:
        page = self.current_page()
        kind = page["kind"]

        if kind == "collect":
            self.start_collection(str(page["phase"]), float(page["duration"]))
            return

        write_config(self.config, self.port, self.baud)
        if self.start_stage == "click" and self.page_index == 4:
            self.save_session()
            messagebox.showinfo("클릭 저장 완료", f"저장됨:\n{LATEST_JSON}\n{HEADER_OUT}")
            return

        if kind == "save":
            self.save_session()
            messagebox.showinfo("저장 완료", f"저장됨:\n{LATEST_JSON}\n{HEADER_OUT}")
            return

        self.next_page()

    def adjust_current(self, direction: int) -> None:
        page = self.current_page()
        if page["kind"] not in {"adjust", "imu"}:
            return

        value = float(get_nested(self.config, page["path"]))
        value = max(float(page["low"]), min(float(page["high"]), value + float(page["step"]) * direction))
        digits = int(page["digits"])
        value = int(round(value)) if digits == 0 else round(value, digits)
        set_nested(self.config, page["path"], value)

        if page["kind"] == "imu":
            self.worker.send(f"{page['command']}={value}")

        write_config(self.config, self.port, self.baud)
        self.render_page()

    def start_collection(self, label: str, duration_s: float) -> None:
        self.worker.set_label(label)
        self.phase_samples[label] = []
        self.collection_label = label
        self.collection_end_time = time.monotonic() + duration_s
        self.status = f"{label} 수집 중"

    def capture_collection_sample(self, sample: Sample) -> None:
        if self.collection_label is None:
            return
        self.phase_samples.setdefault(self.collection_label, []).append(sample)
        self.samples.append(sample)

    def finish_collection_if_due(self) -> None:
        if self.collection_label is None or time.monotonic() < self.collection_end_time:
            return

        label = self.collection_label
        count = len(self.phase_samples.get(label, []))
        self.collection_label = None
        self.collection_end_time = 0.0
        self.status = f"{label} 수집 완료 ({count} samples)"
        self.apply_phase_fit(label)
        self.next_page()

    def apply_phase_fit(self, label: str) -> None:
        idle = self.phase_samples.get("idle", [])
        if label == "idle" and len(idle) >= 20:
            self.config["flex"]["left"]["baseline_adc"] = round(median([sample.a0 for sample in idle]), 3)
            self.config["flex"]["right"]["baseline_adc"] = round(median([sample.a1 for sample in idle]), 3)
            self.update_opposite_reject()
            return

    def update_opposite_reject(self) -> None:
        left_delta = int(self.config["flex"]["left"]["press_delta"])
        right_delta = int(self.config["flex"]["right"]["press_delta"])
        self.config["flex"]["opposite_delta_max"] = int(round(max(left_delta, right_delta) * 0.8))

    def process_sample(self, sample: Sample) -> None:
        self.prev_sample = self.latest_sample
        self.latest_sample = sample
        self.live_samples.append(sample)
        if len(self.live_samples) > 220:
            self.live_samples = self.live_samples[-220:]
        self.capture_collection_sample(sample)

        if self.prev_sample is None:
            return

        dt_ms = sample.t_ms - self.prev_sample.t_ms
        if dt_ms <= 0:
            return

        left_cfg = self.config["flex"]["left"]
        right_cfg = self.config["flex"]["right"]
        left_delta = int(left_cfg["active_sign"]) * (sample.a0 - float(left_cfg["baseline_adc"]))
        prev_left_delta = int(left_cfg["active_sign"]) * (self.prev_sample.a0 - float(left_cfg["baseline_adc"]))
        right_delta = int(right_cfg["active_sign"]) * (sample.a1 - float(right_cfg["baseline_adc"]))
        prev_right_delta = int(right_cfg["active_sign"]) * (self.prev_sample.a1 - float(right_cfg["baseline_adc"]))
        alpha = 0.35
        self.left_slope += (((left_delta - prev_left_delta) * 1000.0 / dt_ms) - self.left_slope) * alpha
        self.right_slope += (((right_delta - prev_right_delta) * 1000.0 / dt_ms) - self.right_slope) * alpha

        if not self.left_hold_on and self.left_slope >= float(left_cfg["press_slope_adc_per_s"]):
            self.left_hold_on = True
            self.left_hold_started_ms = sample.t_ms
        elif self.left_hold_on and left_delta <= float(left_cfg["release_delta"]):
            self.left_hold_on = False
            self.left_hold_started_ms = 0

        if not self.right_hold_on and self.right_slope >= float(right_cfg["press_slope_adc_per_s"]):
            self.right_hold_on = True
            self.right_hold_started_ms = sample.t_ms
        elif self.right_hold_on and right_delta <= float(right_cfg["release_delta"]):
            self.right_hold_on = False
            self.right_hold_started_ms = 0

    def parse_config_reply(self, line: str) -> None:
        tokens = line.replace("OK ", "").replace("CFG ", "").split()
        for token in tokens:
            if ":" not in token:
                continue
            key, raw_value = token.split(":", 1)
            try:
                value = float(raw_value)
            except ValueError:
                continue
            if key == "sx":
                self.config["imu"]["cursor_x_sensitivity"] = value
            elif key == "sy":
                self.config["imu"]["cursor_y_sensitivity"] = value
            elif key == "dz":
                self.config["imu"]["cursor_deadzone_dps"] = value
            elif key == "bias_x":
                self.config["imu"]["gyro_bias_dps"]["x"] = value
            elif key == "bias_y":
                self.config["imu"]["gyro_bias_dps"]["y"] = value
            elif key == "bias_z":
                self.config["imu"]["gyro_bias_dps"]["z"] = value

    def send_runtime_values(self) -> None:
        self.worker.send(f"SX={self.config['imu']['cursor_x_sensitivity']}")
        self.worker.send(f"SY={self.config['imu']['cursor_y_sensitivity']}")
        self.worker.send(f"DZ={self.config['imu']['cursor_deadzone_dps']}")
        self.worker.send("PRINT")

    def save_session(self) -> None:
        if not self.samples:
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_dir = SESSIONS_DIR / f"test1_flex_{timestamp}"
        session_dir.mkdir(parents=True, exist_ok=True)
        write_samples_csv(session_dir / "test1_flex_calibration_samples.csv", self.samples)
        (session_dir / "test1_flex_calibration.json").write_text(
            json.dumps(self.config, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def save_and_close(self) -> None:
        write_config(self.config, self.port, self.baud)
        self.on_close()

    def update_loop(self) -> None:
        try:
            while True:
                item = self.rx_queue.get_nowait()
                if isinstance(item, Sample):
                    self.process_sample(item)
                elif isinstance(item, tuple) and item[0] == "status":
                    self.status = str(item[1])
                elif isinstance(item, tuple) and item[0] == "error":
                    self.error = str(item[1])
                elif isinstance(item, tuple) and item[0] == "serial":
                    self.last_reply = str(item[1])
                    if self.last_reply.startswith("CFG") or self.last_reply.startswith("OK"):
                        self.parse_config_reply(self.last_reply)
                    if self.bias_pending and "BIAS" in self.last_reply and "bias_x:" in self.last_reply:
                        self.bias_pending = False
                        write_config(self.config, self.port, self.baud)
                        self.next_page()
        except queue.Empty:
            pass

        self.finish_collection_if_due()
        self.render_page()
        self.render_live()
        self.root.after(60, self.update_loop)

    def render_live(self) -> None:
        self.canvas.delete("all")
        width = max(980, self.canvas.winfo_width())
        height = max(420, self.canvas.winfo_height())
        mid = height / 2
        self.canvas.create_line(40, mid, width - 30, mid, fill="#cbd5e1")

        left_cfg = self.config["flex"]["left"]
        right_cfg = self.config["flex"]["right"]
        recent = self.live_samples[-180:]
        if len(recent) > 1:
            xs = [40 + i * (width - 80) / max(1, len(recent) - 1) for i in range(len(recent))]
            left_points = []
            right_points = []

            def y(value: float) -> float:
                return mid - max(-mid + 30, min(mid - 30, value * 2.0))

            for x_pos, sample in zip(xs, recent):
                ld = int(left_cfg["active_sign"]) * (sample.a0 - float(left_cfg["baseline_adc"]))
                rd = int(right_cfg["active_sign"]) * (sample.a1 - float(right_cfg["baseline_adc"]))
                left_points.extend([x_pos, y(ld)])
                right_points.extend([x_pos, y(rd)])
            self.canvas.create_line(left_points, fill="#2563eb", width=2)
            self.canvas.create_line(right_points, fill="#f97316", width=2)

        left_hold_ms = 0
        right_hold_ms = 0
        if self.latest_sample is not None:
            if self.left_hold_on and self.left_hold_started_ms:
                left_hold_ms = max(0, self.latest_sample.t_ms - self.left_hold_started_ms)
            if self.right_hold_on and self.right_hold_started_ms:
                right_hold_ms = max(0, self.latest_sample.t_ms - self.right_hold_started_ms)

        double_ready = self.left_hold_on and left_hold_ms >= int(self.config["gesture"]["long_gesture_hold_ms"])
        drag_ready = self.right_hold_on and right_hold_ms >= int(self.config["gesture"]["drag_start_hold_ms"])
        axis_ready = (
            self.left_hold_on and
            self.right_hold_on and
            min(left_hold_ms, right_hold_ms) >= int(self.config["gesture"]["axis_swap_hold_ms"])
        )
        self.canvas.create_rectangle(40, height - 72, 190, height - 32, fill="#22c55e" if self.left_hold_on else "#e2e8f0", outline="")
        self.canvas.create_rectangle(210, height - 72, 360, height - 32, fill="#22c55e" if self.right_hold_on else "#e2e8f0", outline="")
        self.canvas.create_rectangle(380, height - 72, 570, height - 32, fill="#22c55e" if double_ready else "#e2e8f0", outline="")
        self.canvas.create_rectangle(590, height - 72, 780, height - 32, fill="#22c55e" if drag_ready else "#e2e8f0", outline="")
        self.canvas.create_rectangle(800, height - 72, 970, height - 32, fill="#22c55e" if axis_ready else "#e2e8f0", outline="")
        self.canvas.create_text(115, height - 52, text="좌클릭 ON" if self.left_hold_on else "좌클릭 off", font=("Segoe UI", 10, "bold"))
        self.canvas.create_text(285, height - 52, text="우클릭 ON" if self.right_hold_on else "우클릭 off", font=("Segoe UI", 10, "bold"))
        self.canvas.create_text(475, height - 52, text="더블 READY" if double_ready else "더블 off", font=("Segoe UI", 10, "bold"))
        self.canvas.create_text(685, height - 52, text="드래그 READY" if drag_ready else "드래그 off", font=("Segoe UI", 10, "bold"))
        self.canvas.create_text(885, height - 52, text="부호 전환 READY" if axis_ready else "부호 전환 off", font=("Segoe UI", 10, "bold"))

        if self.latest_sample is None:
            sample_text = "시리얼 샘플 대기 중"
        else:
            ld = int(left_cfg["active_sign"]) * (self.latest_sample.a0 - float(left_cfg["baseline_adc"]))
            rd = int(right_cfg["active_sign"]) * (self.latest_sample.a1 - float(right_cfg["baseline_adc"]))
            sample_text = (
                f"A0 raw={self.latest_sample.a0:4d} delta={ld:7.1f} slope={self.left_slope:8.1f} | "
                f"A1 raw={self.latest_sample.a1:4d} delta={rd:7.1f} slope={self.right_slope:8.1f}"
            )

        collection_text = ""
        if self.collection_label is not None:
            remaining = max(0.0, self.collection_end_time - time.monotonic())
            collection_text = f"\n수집 중: {self.collection_label} ({remaining:.1f}s 남음)"

        counts = ", ".join(f"{key}:{len(value)}" for key, value in self.phase_samples.items()) or "아직 없음"
        self.metrics.config(
            text=(
                f"상태: {self.status}  stream={'ON' if self.stream_enabled else 'OFF'}  {self.port}@{self.baud}\n"
                f"{sample_text}\n"
                f"A0 threshold={float(left_cfg['press_slope_adc_per_s']):.1f}  "
                f"A1 threshold={float(right_cfg['press_slope_adc_per_s']):.1f}  "
                f"A0 release={int(left_cfg['release_delta'])}  "
                f"A1 release={int(right_cfg['release_delta'])}\n"
                f"SX={self.config['imu']['cursor_x_sensitivity']}  "
                f"SY={self.config['imu']['cursor_y_sensitivity']}  "
                f"DZ={self.config['imu']['cursor_deadzone_dps']}  "
                f"SIGN={self.config['gesture']['axis_swap_hold_ms']}ms  "
                f"bias=({self.config['imu']['gyro_bias_dps']['x']}, "
                f"{self.config['imu']['gyro_bias_dps']['y']}, "
                f"{self.config['imu']['gyro_bias_dps']['z']})\n"
                f"수집 샘플: {counts}{collection_text}\n"
                f"마지막 응답: {self.last_reply}\n"
                f"오류: {self.error}"
            )
        )

    def on_close(self) -> None:
        self.worker.send("STREAM=0")
        self.worker.stop()
        self.worker.join(timeout=1.0)
        self.root.destroy()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default=SERIAL_PORT)
    parser.add_argument("--baud", type=int, default=BAUD_RATE)
    parser.add_argument("--stage", choices=["all", "click", "imu"], default="all")
    args = parser.parse_args()

    port = choose_serial_port(args.port)
    start_stage = "imu" if args.stage == "imu" else "all"
    root = tk.Tk()
    Test1FlexSensorCalibrationGui(root, port, args.baud, start_stage)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
